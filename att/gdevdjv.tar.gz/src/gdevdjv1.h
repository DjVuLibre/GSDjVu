/* -*- Mode: c; c-file-style: "bsd"; -*- 
   $Id: gdevdjv1.h,v 2.2 2001/02/12 17:05:08 leonb Exp $
   -------------------------------------------------------------------------- 
   Useful algorithms.
   Most of these things are reconstructed 
   from my personal trick book.
   -- Leon Bottou, June-October 2000
   -- Copyright (C) 2000 AT&T.
*/

#include "stdpre.h"
#include "arch.h"
#include "ctype_.h"
#include "memory_.h"
#include "stdio_.h"
#include "string_.h"
#include <stdlib.h>     /* for qsort */
#include "gserror.h"
#include "gserrors.h"
#include "gsmemory.h"
#include "gstypes.h"
#include "gsrect.h"
#include "gscdefs.h"
#include "gsstruct.h"
#include "gsmalloc.h"
#include "gxalloc.h"
#include "gxcindex.h"
#include "gxstdio.h"


/* ====================================== 
              U T I L I T I E S
   ======================================  */

/* Return memory error code */
#define return_VMerror \
    return_error(gs_error_VMerror)

/* Check for internal errors. */
#define ASSERT(cond) \
  while (!(cond)) lbassertfail(__FILE__,__LINE__);
#ifdef __GNUC__
extern void lbassertfail(const char *, int) __attribute__ ((noreturn));
extern void abort(void) __attribute__ ((noreturn));
#endif



/* ======================================
              P 2 M E M
   ====================================== */

/* Runmaps were initially putting a lot of stress on the Ghostscript standard
   memory allocator, causing fragmentation and creating lots of long-lived
   small objects.  The fragmentation issue was the major concern in gs6_23,
   sometimes accounting for more than 95% of the computation time.  Allocator
   improvements by L. Peter Deutsch basically eliminated that problem.  Yet
   the Ghostscript garbage collector was still spending a lot of time scanning
   these long lists of small objects, never finding memory to reclaim.  The
   following memory allocator was included in order to ``stay out of the
   way''.  Memory is obtained from the low level GS allocator in chunks.  Some
   chunks merely contain a single large object (large blocks).  The other
   chunks contain a number of small objects (small blocks).  Small block sizes
   are always constrained to be a power-of-two, minus two marker bytes located
   before and after the block. The marker byte simply contains the log2 of the
   block size (3 for 8 bytes, 4 for 16 bytes, etc.).  A marker byte of 255
   indicates a large block allocated alone in its chunk. */


/* Required alignment for p2mem allocated objects */
#define p2mem_log2_align  log2_obj_align_mod
#define p2mem_align       obj_align_mod

/* Parent allocator */
#define p2mem_parent_alloc(size) \
  (void *)gs_alloc_bytes_immovable(&gs_memory_default, size, "p2mem")
#define p2mem_parent_resize(data, newsize) \
  (void*)gs_resize_object(&gs_memory_default, data, newsize, "p2mem")
#define p2mem_parent_free(data) \
   gs_free_object(&gs_memory_default, data, "p2mem")

/* Internal: minimal and maximal size of small objects */
#ifndef arch_log2_sizeof_ptr
#if arch_sizeof_ptr == 4
#define arch_log2_sizeof_ptr 2
#elif arch_sizeof_ptr == 8
#define arch_log2_sizeof_ptr 3
#endif
#endif
#if p2mem_log2_align > arch_log2_sizeof_ptr
#define p2mem_log2_min    p2mem_log2_align
#define p2mem_log2_max    (11)
#else
#define p2mem_log2_min    (arch_log2_sizeof_ptr+1)
#define p2mem_log2_max    (11)
#endif
#define p2mem_min         (1<<p2mem_log2_min)
#define p2mem_max         (1<<p2mem_log2_max)
#define p2mem_chunksize   (31)

/* Memory allocator */
typedef struct p2mem_s p2mem;

/* Create an allocator */
extern p2mem *p2mem_create(void);

/* Free all objects from an allocator */
extern void p2mem_freeall(p2mem *mem);

/* Destroy an allocator. */
extern void p2mem_destroy(p2mem *mem);

/* Allocate a piece of memory */
extern void *p2mem_alloc(p2mem *mem, uint size);

/* Free a piece of memory */
extern void p2mem_free(p2mem *mem, void *vdata);

/* Resize a piece of memory */
extern void *p2mem_resize(p2mem *mem, void *vdata, uint newsize);

#ifdef DEBUG
/* Display debugging information about p2mem internals */
void p2mem_diag(p2mem *mem);
#endif





/* ======================================
                R U N M A P
   ====================================== */

/* Memory efficient algorithms for performing boolean operations between run
   length encoded bitonal images.  Each row is represented by the lengths of
   alternating white and black pixels.  Each length can be encoded on one to
   three bytes.  Data for row <y> is located in array <data> between offsets
   <rows[y-ymin]> and <rows[y-ymin+1]>.  Empty runmaps are represented by null
   pointers */

typedef struct runmap_s {
    uint ymin, ymax, xmin, xmax;
    uint rlen, dlen;
    p2mem *mem;
    uint  *rows;
    byte  *data;
} runmap;

/* Deallocate runmap */
extern void runmap_free(runmap *a);

/* Encode run length x at location data */
#define rl_encode(data, x) { \
  if ((uint)(x)<0xc0) { *data++ = (x); } \
  else if ((uint)(x)<0x2000) { \
         *data++ = (((x)>>8)|0xc0); *data++ = ((x)&0xff); } \
  else if ((uint)(x)<0x200000) { *data++ = (((x)>>16)|0xe0); \
         *data++ = ((x)&0xff00)>>8; *data++ = ((x)&0xff); } \
  else ASSERT(0); }

/* Decode run length at location data and increment x */
#define rl_decode(data, x) { \
  if (data[0] < 0xc0) { x += data[0]; data+=1; } \
  else if (data[0] < 0xe0) { x += (data[1]|(data[0]<<8))-0xc000; data+=2; } \
  else { x += (data[2]|(data[1]<<8)|(data[0]<<16))-0xe00000; data+=3; } }
  

/* Accumulating small objects into a large runmap can be very inefficient
   because each call to runmap_or must copy the unchanged part of the large
   runmap.  The problem is easily circumvented by using a smaller intermediate
   runmap.  The small objects are accumulated into the intermediate runmap.
   The intermediate runmap is accumulated into the large runmap whenever its
   size exceeds a predefined threshold.  The following macro checks whether it
   is time to transfer the intermediate runmap into the large runmap. */
#define runmap_becoming_big(r)  ((r) && (r)->dlen > 2048)

/* Check whether runmaps a and b collide. */
extern bool runmap_hittest(runmap *a, runmap *b);

/* Pointer to triples {y,x1,x2} representing runs. */
typedef uint (*runptr)[3];

/* Compute bitwise OR of a runmap and an ordered array of triples <{y,x1,x2}>.
   Runmap A will be freed if <(del&1)> is non zero.  Resulting runmap is
   returned through pointer <out>. */
extern int runmap_or_runs(p2mem *mem, runmap *a, runptr runs, int nruns, 
                          int del, runmap **out);

/* Compute bitwise OR of two runmaps.  Runmap <a> will be freed if <(del&1)>
   is non zero.  Runmap <b> will be freed if <(del&2)> is non zero.  Resulting
   runmap is returned through pointer <out>. */
extern int runmap_or(p2mem *mem, runmap *a, runmap *b, 
                     int del, runmap **out);

/* Compute bitwise AND of two runmaps.  Runmap <a> will be freed if <(del&1)>
   is non zero.  Runmap B will be freed if <(del&2)> is non zero.  Resulting
   runmap is returned through pointer <out>. */
extern int runmap_and(p2mem *mem, runmap *a, runmap *b, 
                     int del, runmap **out);

/* Compute bitwise SUBTRACT of two runmaps.  Runmap <a> will be freed if
   <(del&1)> is non zero.  Runmap <b> will be freed if <(del&2)> is non zero.
   Resulting runmap is returned through pointer <out>. */
extern int runmap_andnot(p2mem *mem, runmap *a, runmap *b, 
                         int del, runmap **out);

/* Compute area and perimeter of runmap. */
extern void runmap_info(runmap *r, int *parea, int *pperimeter);

/* Save a runmap as PBM */
extern int runmap_save(runmap *r, FILE *f, 
                       uint xmin, uint xmax, uint ymin, uint ymax, 
                       const char *comment);

/* Draws a runmap with a specified color into a raster pixmap.  Raster covers
   rectangle <cwxch+cx+cy>. Pointer <base> indicates position <(cx,cy)>.
   Integer <sraster> represents the pointer difference from one line to the
   next. */
extern void runmap_play(runmap *r, gx_color_index color,
                        byte *base, int sraster, 
                        uint cx, uint cy, uint cw, uint ch);

/* ======================================
            R U N M A P B L D
   ====================================== */

/* Runmap builders allow the efficient construction of rmap using arbitrarily
   ordered black runs.  Each black run is added using runmapbld_write() and
   extends from column x1 to x2 (inclusive) on row y.  Runs are stored in a
   temporary buffer and ORed into the current runmap.  The final runmap is
   computed when runmapbld_close() is called. */

/* The runmapbld data structure */
typedef struct runmapbld_s {
    p2mem *mem;
    runmap *rmap;
    runptr runs;
    uint nruns;
    uint nrunsmax;
    bool needsort;
} runmapbld;

/* Recommended buffer size for a runmapbld */
#define runmapbld_buffer_size 5000

/* Create a runmapbld. */
extern int runmapbld_open(p2mem *mem, uint nrunsmax, runmapbld **out);

/* Compute up-to-date runmap . */
extern int runmapbld_flush(runmapbld *bld);

/* Add run <{y,x1,x2}> to the runmapbld. */
extern int runmapbld_write(runmapbld *bld, int y, int x1, int x2);

/* Destroy runmap builder, release memory, and return runmap. */
extern int runmapbld_close(runmapbld *bld, runmap **out);

/* Accumulate a rectangle into a runmapbld */
extern int runmapbld_put_rect(runmapbld *bld, int xx, int yy, int w, int h);

/* Accumulate a bitmap into a runmapbld.
   Arguments <base>, <sourcex>, <sraster>, <xx>, <yy>, <w> and <h>
   are as in ghostscript.  Setting <xor> to <0> copies all black pixels
   into the runmapbld.  Setting <xor> to <0xff> copies all white pixels
   and produces a reverse video effect. */
extern int runmapbld_put_bitmap(runmapbld *bld,
                                const byte *base, int sourcex, 
                                int sraster, int xor,
                                int xx, int yy, int w, int h);




/* ======================================
           H A S H   T A B L E
   ====================================== */

/* Generic hash table.  Each hash table entry starts with a user
   defined payload structure whose first component is the key.  In the
   simplest case, you just specify the size of the payload when 
   creating the hash table.  You might then override procedure pointers 
   for comparing keys, copying keys, and releasing extra memory associated 
   with the payload structure.  Macro htable_lookup() gives a pointer to 
   the payload structure associated with a particular key.  You can then 
   consult or change any additional field in the payload structure.  
   A null pointer is returned if the key is not found and argument 
   create is false.  */

typedef struct htable_s {
    p2mem *mem;     /* memory allocator */
    int psize;      /* payload size */
    int xsize;      /* payload size rounded for alignment */
    int nelems;     /* number of elements */
    int nbuckets;   /* number of hash buckets */
    void **buckets; /* pointer to entries in each bucket */
    /* Procedure pointer you can override */
    bool (*key_equal)(const void *key1, const void *key2);
    void (*key_copy)(p2mem *mem, void *dst, const void *src);
    void (*payload_release)(p2mem *mem, void *payload);
} htable;



/* Create a hash table. */
extern htable *htable_alloc(p2mem *mem, int payloadsize);

/* Destroy a hash table */
extern void htable_free(htable *h);

/* Htable lookup function. Returns a payload pointer if a matching entry is
   found, otherwise creates a new entry or return a null pointer according
   to flag ``create''.  Note the the type of argument ``pkey'' *must* be
   ``pointer to the key type''.  Note that argument hash must be the hashcode
   for the key pointed to by ``pkey''. */
#define htable_lookup(htbl, pkey, hash, create) \
   (htable_lookup_sub(htbl, pkey, sizeof(*pkey), hash, create))

/* Internal: helper for htable_lookup() */
extern void *htable_lookup_sub(htable *h, const void *key, 
                               int keysize, uint hash, bool create);

/* Internal: hash table entry fields following the payload */
typedef struct htablelink_s {
    uint hash;
    void *next;
} htablelink;

/* Iterate on hash table entries. */
#define htable_begin_loop(pptr, h) {\
   int _b_; \
   for ( _b_ = 0; _b_ < (h)->nbuckets; _b_++ ) { \
      pptr = (h)->buckets[_b_]; \
      while (pptr) { 

#define htable_end_loop(pptr, h) \
        pptr = ((htablelink*)((char*)(pptr) + (h)->xsize))->next; } \
      } }



/* ======================================
    C O L O R   Q U A N T I Z A T I O N
   ====================================== */

/* Payload for color histogram hash table */
typedef struct colordata_s {
    gx_color_index color; 
    uint w; 
} colordata;

/* Hash function for colors. */
#define hash_rgb(rgb) \
   (((rgb) & 0xffffff)^(((rgb) & 0xffff)<<4))

/* Allocate a color hash table */
#define colorhash_alloc(mem) \
   (htable_alloc(mem, sizeof(colordata)))

/* Free color hash table */
#define colorhash_free(colorhash) \
   htable_free(colorhash)

/* Add contribution to a histogram */
int colorhash_add(htable *colorhash, 
                  gx_color_index color, uint w);

/* Reduce number of colors.  Input <colorhash> is a color hash table
   containing a color histogram.  This function will allocate a palette array
   <*ppalette> and return its size as <*psize>.  The weights in the color hash
   table will be replaced by the palette index.  */
int color_quantize(p2mem *mem, htable *colorhash, uint maxcolors,
                   gx_color_index **ppalette, uint *psize);



/* ======================================
               C H R O M E
   ====================================== */

/* A chrome object represent a collection of images represented by a sequence
   of rendering opcodes that can be replayed at later times.  Each image is
   identified by a chrome_pos object that defines its offset and length in the
   chrome object.  */
typedef struct chrome_s chrome;

/* Allocate a chrome object */
extern chrome *chrome_create(void);

/* Destroy a chrome object */
extern void chrome_destroy(chrome *cr);

/* Data structure recording current chrome position */
typedef struct chrome_pos_s chrome_pos;

/* Create a chrome_pos indentifying the next image
   in the chrome object. */
extern chrome_pos *chrome_getpos(chrome *cr);

/* Terminate the current image in the chrome object and 
   update the length in the corresponding chrome_pos object */
extern void chrome_closepos(chrome *cr, chrome_pos *cpos);

/* Appends a filled rectangle to the current image */
int chrome_put_rect(chrome *cr, int x, int y, 
                    int w, int h, gx_color_index c);

/* Appends a monochrome runmap to the current image */
int chrome_put_runmap(chrome *cr, runmap *r, gx_color_index c);

/* Appends a monochrome bitmap to the current image.  The bitmap is described
   by <base>, <sourcex>, <sraster>, <xx>, <yy>, <w>, <h> as in ghostscript.
   Its colors are specified by arguments <c0> and <c1>. Colors can be
   <gx_no_color_index> to indicate transparency. */
int chrome_put_bitmap(chrome *cr, 
                      const byte * base, int sourcex, int sraster,
                      int xx, int yy, int w, int h, 
                      gx_color_index c0, gx_color_index c1);

/* Appends a 24 bit color pixmap to the current image.  The pixmap is
   described by <base>, <sourcex>, <sraster>, <xx>, <yy>, <w>, <h> as in
   ghostscript */
extern int chrome_put_pixmap(chrome *cr, 
                             const byte * base, int sourcex, int sraster,
                             int xx, int yy, int w, int h);

/* Replay chrome data into a raster pixmap.
   See runmap_play() for an explanation of arguments 
   <base>, <sraster>, <cx>, <cy>, <cw>, and <ch>. */
extern void chrome_play(chrome_pos *cpos, 
                        byte *base, int sraster, 
                        int cx, int cy, int cw, int ch);

/* Replay chrome data intersecting area <cw*ch+cx+cy>,
   (1) accumulating a colormap into <colorhash>,
   (2) storing colordata pointers into a memory buffer <base>.
   Aborts if the total number of colors exceeds <maxcolors>. */
extern int chrome_play_indexed(chrome_pos *cpos, 
                               htable *colorhash, int maxcolors,
                               colordata **base, int sraster, 
                               int cx, int cy, int cw, int ch);



/* ======================================
       C O L O R   R L E   F I L E S
   ====================================== */

/* Color RLE images start with the magic text "R6" followed by three integers
   representing the image width, the image height, and the palette size.
   These integers may be separated by blanks or by comments.  Comments start
   with character '#' and extend until the end of the line.  The last integer
   is followed by exactly one blank character (typically a new line).  Then
   come <palettesize> groups of three bytes (r,g,b) representing palette
   entries.  This is followed by a sequence of 32 bit integers (MSB first)
   whose low 20 bits represent a run length and high 12 bits represent the run
   color index.  Color indices are in range <0...palettesize-1>.  Color
   indices greater than 0xff0 are reserved.  Indice 0xfff represents the
   transparent color.  Runs are arranged in lexicographical order (top to
   bottom).  A line ends when the sum of run lengths is a multiple of the
   image width. */

extern int crle_save(p2mem *mem,
                     int width, int height,
                     gx_color_index *palette, uint palettesize,
                     int num, runmap **rmaps, gx_color_index *colors,
                     const char *comment,  
                     FILE *outfile);
