/* -*- Mode: c; c-file-style: "bsd"; -*- 
   $Id: gdevdjv1.c,v 2.3 2001/04/17 01:15:39 leonb Exp $
   -------------------------------------------------------------------------- 
   Useful algorithms.
   Most of these things are reconstructed 
   from my personal trick book.
   -- Leon Bottou, June-October 2000
   -- Copyright (C) 2000 AT&T.
*/

#include "gdevdjv1.h"


/* ====================================== 
              U T I L I T I E S
   ======================================  */

/* Called by macro ASSERT defined in the H file */
void 
lbassertfail(const char *file, int line)
{
    fprintf(stderr,"Internal error at %s:%d\n", file, line);
    abort();
}



/* ======================================
              P 2 M E M
   ====================================== */

/* Memory allocator */
struct p2mem_s {
    byte *cc;  /* slist of chunks containing small blocks. */
    byte *cb;  /* dlist of chunks containing a single large block. */
    uint cc_used; 
    uint cc_total;
    byte *freelist[p2mem_log2_max+1];
};

/* Create an allocator. */
p2mem *
p2mem_create(void) 
{
    p2mem *mem = p2mem_parent_alloc(sizeof(p2mem));
    if (mem) memset(mem, 0, sizeof(p2mem));
    return mem;
}

/* Free everything in an allocator. */
void
p2mem_freeall(p2mem *mem) 
{
    if (mem) {
        while (mem->cc) {
            byte *cc = mem->cc;
            mem->cc = *(byte**)cc;
            p2mem_parent_free(cc);
        }
        while (mem->cb) {
            byte *cb = mem->cb;
            mem->cb = *(byte**)cb;
            p2mem_parent_free(cb);
        }
    }
    memset(mem, 0, sizeof(p2mem));
}

/* Destroy an allocator. */
void
p2mem_destroy(p2mem *mem) 
{
    if (mem) {
        p2mem_freeall(mem);
        p2mem_parent_free(mem);
    }
}

/* Internal: get a small block. */
private byte *
p2mem_getblock(p2mem *mem, uint log2)
{
    if (mem->freelist[log2]) {
        /* Get it from freelist */
        byte *data = mem->freelist[log2];
        mem->freelist[log2] = *(byte**)data;
        mem->cc_used += (1<<log2);
        return data;
    } else if (log2 < p2mem_log2_max) {
        /* Get it by splitting larger block */
        int size = (1<<log2);
        byte *data = p2mem_getblock(mem, log2+1);
        if (!data) return 0;
        data[-1] = data[size-2] = log2;
        data[size-1] = data[size+size-2] = log2;
        *(byte**)&data[size] = mem->freelist[log2];
        mem->freelist[log2] = &data[size];
        mem->cc_used -= size;
        return data;
    } else {
        /* Allocate new chunk */
        int overhead = sizeof(byte*) | ((1<<p2mem_log2_align)-1);
        int chunksize = overhead + p2mem_chunksize * p2mem_max;
        byte *cc = p2mem_parent_alloc(chunksize);
        byte *data = cc + chunksize + 1;
        int nblocks = p2mem_chunksize;
        if (!cc) return 0;
        *(byte**)cc = mem->cc;
        mem->cc = cc;
        mem->cc_total += chunksize;
        while (nblocks-- > 0) {
            data -= p2mem_max;
            data[-1] = data[p2mem_max-2] = p2mem_log2_max;
            *(byte**)data = mem->freelist[p2mem_log2_max];
            mem->freelist[p2mem_log2_max] = data;
        }
        /* Return block */
        data = mem->freelist[p2mem_log2_max];
        mem->freelist[p2mem_log2_max] = *(byte**)data;
        mem->cc_used += p2mem_max;
        return data;
    }
}

/* Allocate data. */
void *
p2mem_alloc(p2mem *mem, uint size) 
{
    if (size > 0) {
        size = size + 2;
        if (size <= p2mem_max) {
            /* Compute suitable power of two */
            int log2 = p2mem_log2_min;
            int blocksize = (1<<log2);
            while (blocksize < size) {
                log2++;
                blocksize <<= 1;
            }
            /* Allocate */
            return p2mem_getblock(mem, log2);
        } else {
            /* Large block */
            int overhead = 2*sizeof(byte*) + ((1<<p2mem_log2_align)-1);
            byte *cb = p2mem_parent_alloc(size + overhead);
            if (!cb) return 0;
            if (mem->cb) { ((byte**)(mem->cb))[1] = cb; }
            ((byte**)cb)[0] = mem->cb;
            ((byte***)cb)[1] = &(mem->cb);
            mem->cb = cb;
            cb[overhead] = 0xff;
            cb[overhead+size-1] = 0xff;
            return cb + overhead + 1;
        }
    }
    return 0;
}

/* Free data block. */
void
p2mem_free(p2mem *mem, void *vdata)
{
    if (vdata) {
        byte *data = vdata;
        int log2 = data[-1];
        if (log2 <= p2mem_log2_max) {
            /* Small blocks */
            int blocksize = (1<<log2);
            ASSERT(log2>=p2mem_log2_min);
            ASSERT(data[blocksize-2] == log2);
            *(byte**)data = mem->freelist[log2];
            mem->freelist[log2] = data;
            mem->cc_used -= blocksize;
        } else {
            /* Large blocks */
            int overhead = 2*sizeof(byte*) + ((1<<p2mem_log2_align)-1);
            byte *cb = data - overhead - 1;
            byte *cb2 = ((byte**)cb)[0];
            ASSERT(log2 == 0xff);
            if (cb2) { ((byte***)cb2)[1] = ((byte***)cb)[1]; }
            ((byte***)cb)[1][0] = ((byte**)cb)[0];
            p2mem_parent_free(cb);
        }
    }
}

/* Resize data block. */
void *
p2mem_resize(p2mem *mem, void *vdata, uint newsize)
{
    if (newsize == 0) {
        p2mem_free(mem, vdata);
    } else if (vdata == 0) {
        return p2mem_alloc(mem, newsize);
    } else {
        byte *data = vdata;
        int log2 = data[-1];
        newsize += 2;
        if (log2 <= p2mem_log2_max) {
            /* Small block reallocation */
            int blocksize = (1<<log2);
            if (newsize <= blocksize) {
                if (newsize < p2mem_min)
                    newsize = p2mem_min;
                /* No change if blocksize is adequate. */
                if (newsize+newsize > blocksize)
                    return data;
                /* Otherwise fallback to copy.  Splitting the block until
                   reaching the right blocksize causes very inefficient
                   fragmentation. */
            }
        } else if (newsize >= p2mem_max) {
            /* Large block reallocation */
            int overhead = 2*sizeof(byte*) + ((1<<p2mem_log2_align)-1);
            byte *cb = data - overhead - 1;
            byte *cb2 = ((byte**)cb)[0];
            ASSERT(log2 == 0xff);
            if (cb2) { ((byte***)cb2)[1] = ((byte***)cb)[1]; }
            ((byte***)cb)[1][0] = ((byte**)cb)[0];
            cb2 = p2mem_parent_resize(cb, newsize+overhead);
            if (!cb2) return 0;
            if (mem->cb) { ((byte**)(mem->cb))[1] = cb2; }
            ((byte**)cb2)[0] = mem->cb;
            ((byte***)cb2)[1] = &(mem->cb);
            mem->cb = cb2;
            cb2[overhead] = 0xff;
            cb2[overhead+newsize-1] = 0xff;
            return cb2 + overhead + 1;
        }
        /* Fallback: copy data */
        data = p2mem_alloc(mem, newsize);
        if (!data) return 0;
        memcpy(data, vdata, newsize-2);
        p2mem_free(mem, vdata);
        return data;
    }
    return 0;
}

#ifdef DEBUG
void
p2mem_diag(p2mem *mem)
{
    int i;
    byte *ptr, **pptr;
    int cbnum = 0;
    int cctotalfree = 0;
    fprintf(stderr,"cc: %d-%d=%d  (", 
            mem->cc_total, mem->cc_used, 
            mem->cc_total - mem->cc_used );
    for (i=p2mem_log2_min; i<p2mem_log2_max+1; i++) {
        int ccfree = 0;
        ptr = mem->freelist[i];
        while (ptr) { ccfree += 1; ptr = *(byte**)ptr; }
        cctotalfree += (1<<i) * ccfree;
        fprintf(stderr," %d", ccfree);
    }
    fprintf(stderr," ) = %d ", cctotalfree);
    pptr = &mem->cb;
    while ((ptr = *pptr)) {
        ASSERT( ((byte***)ptr)[1] == pptr );
        pptr = (byte**)ptr;
        cbnum += 1;
    }
    fprintf(stderr," cb: %d\n", cbnum);
}
#endif








/* ======================================
                R U N M A P
   ====================================== */

/* Deallocate runmap */
void
runmap_free(runmap *a)
{
    if (a) { 
        p2mem *mem = a->mem;
        p2mem_free(mem, a->data);
        p2mem_free(mem, a->rows);
        p2mem_free(mem, a);
    }
}

/* Check that data is available and decode run length.*/
#define rl_check_decode(data, dataend, x, c, finished) { \
  if (data < dataend) { c = !c; rl_decode(data,x); } \
  else { x = ARCH_MAX_UINT; finished; } }

/* Check whether runmaps a and b collide. */
bool
runmap_hittest(runmap *a, runmap *b)
{
    int y;
    int ymin, ymax;
    /* determine ymin ymax */
    if (!a || !b) 
        return false;
    ymin = max(a->ymin, b->ymin);
    ymax = min(a->ymax, b->ymax);
    if (ymin > ymax || a->xmin > b->xmax || a->xmax < b->xmin) 
        return false;
    /* loop over lines */
    for (y=ymin; y<=ymax; y++) {
        /* access rows */
        byte *adata = a->data + a->rows[y - a->ymin];
        byte *adataend = a->data + a->rows[y - a->ymin + 1];
        byte *bdata = b->data + b->rows[y - b->ymin];
        byte *bdataend = b->data + b->rows[y - b->ymin + 1];
        /* process row */
        if (bdata < bdataend && adata < adataend) {
            /* something in both rows a and b */
            uint ax = 0;
            uint bx = 0;
            uint cx = 0;
            bool ac = true;
            bool bc = true;
            for(;;) {
                if (ax <= cx) 
		    rl_check_decode(adata, adataend, ax, ac, break);
                if (bx <= cx) 
		    rl_check_decode(bdata, bdataend, bx, bc, break);
		cx = min(ax,bx);
		if (ac && bc)
                    return true;
            }                                   
        }
    }
    /* finish */
    return false;
}

/* Internal: allocate runmap structure. */
private int 
runmap_alloc(p2mem *mem, int dlen, int rlen, runmap **out)
{
    uint *r;
    byte *d;
    runmap *a;
    dlen = max(1,dlen);
    rlen = max(1,rlen);
    a = p2mem_alloc(mem, sizeof(runmap));
    r = p2mem_alloc(mem, sizeof(uint)*rlen);
    d = p2mem_alloc(mem, dlen);
    if (! (a && d && r))
        return_VMerror;
    memset(a, 0, sizeof(runmap));
    a->mem = mem;
    memset(r, 0, sizeof(uint)*rlen);
    a->ymin = ARCH_MAX_UINT;
    a->xmin = ARCH_MAX_UINT;
    a->rlen = rlen;
    a->rows = r;
    a->dlen = dlen;
    a->data = d;
    *out = a;
    return 0;
}

/* Internal: cleanup after boolean operations. */
private int
runmap_finish(p2mem *mem, runmap *c, 
	      runmap *a, runmap *b, int del, runmap **out)
{
    int code;
    /* Check whether a is empty */
    if (c && c->ymin > c->ymax) {
        runmap_free(c);
        c = 0;
    }
    /* Definitely not empty */
    if (c) {
        runmap *from = 0;
        /* Check if we must make a copy */
        if (c == a) { if (del & 1) { a = 0; } else { from = a; } }
        if (c == b) { if (del & 2) { b = 0; } else { from = b; } }
        if (from) {
            /* Make the copy */
            code = runmap_alloc(mem, from->dlen, from->rlen, out);
            if (code < 0) return code;
            c = *out;
            c->ymin = from->ymin;
            c->ymax = from->ymax;
            c->xmin = from->xmin;
            c->xmax = from->xmax;
            memcpy(c->data, from->data, c->dlen);
            memcpy(c->rows, from->rows, sizeof(uint) * c->rlen);
        } else {
            /* Adjust size of runmap memory */
            p2mem *mem = c->mem;
            int rlen = c->ymax - c->ymin + 2;
            int dlen = c->rows[rlen-1];
            if (rlen < c->rlen) 
                c->rows = p2mem_resize(mem, c->rows, rlen*sizeof(uint));
            c->rlen = rlen;
            if (dlen < c->dlen)
                c->data = p2mem_resize(mem, c->data, dlen);
            c->dlen = dlen;
            if (! (c->rows && c->data))
                return_VMerror;
        }
    }
    /* Delete operand runmaps */
    *out = c;
    if (a && (del & 1))
        runmap_free(a);
    if (b && (del & 2))
        runmap_free(b);
    return 0;
}


/* Check that there are remaining triples and obtain a run length.  */
#define rp_check_decode(runs, eruns, y, x, c, finished) { \
  if (runs < eruns && runs[0][0] == y) { c = !c; \
     x = (c ? (runs++)[0][2]+1 : runs[0][1]); } \
  else { x = ARCH_MAX_UINT; finished; } }

/* Compute bitwise OR of a runmap and an ordered array of triples {y,x1,x2}.
   Runmap A will be freed if (DEL&1) is non zero.
   Resulting runmap is returned through pointer OUT. */
int
runmap_or_runs(p2mem *mem, runmap *a, runptr runs, int nruns, 
	       int del, runmap **out)
{
    int y;
    int ymin, ymax, dlen;
    runmap *c = 0;
    byte *cdata;
    runptr eruns = runs + nruns;
    int code;
    /* determine ymin ymax */
    ymin = runs[0][0];
    if (a && a->ymin < ymin)  
        ymin = a->ymin;
    ymax = runs[nruns-1][0];
    if (a && a->ymax > ymax)
        ymax = a->ymax;
    /* allocate runmap */
    dlen = 6*nruns + 4*(ymax-ymin) + (a ? a->dlen : 0);
    code = runmap_alloc(mem, dlen, ymax-ymin+2, &c);
    if (code < 0) return code;
    c->xmin = (a ? a->xmin : ARCH_MAX_UINT);
    c->xmax = (a ? a->xmax : 0);
    cdata = c->data;
    /* loop over lines */
    for (y=ymin; y<=ymax; y++) {
        uint xmin = ARCH_MAX_UINT;
        uint xmax = 0;
        const byte *adata = 0;
        const byte *adataend = 0;
        /* access rows */
        if (a && y >= a->ymin && y <= a->ymax) {
            adata = a->data + a->rows[y - a->ymin];
            adataend = a->data + a->rows[y - a->ymin + 1];
        }
        /* process row */
        if (! (runs<eruns && runs[0][0]==y)) {
            /* nothing in b */
            if (adata < adataend) {
                memcpy(cdata, adata, adataend-adata);
                cdata += adataend - adata;
		xmin = a->xmin;
		xmax = a->xmax;
            }
        } else {
            /* general case */
            uint ax = 0;
            uint bx = 0;
            uint cx = 0;
            uint cx2 = 0;
            bool ac = true;
            bool bc = true;
            uint cc = false;
            uint lastcx = 0;
            uint lastcc = false;
            for(;;) {
                cx = cx2;
                if (ax <= cx)
		    rl_check_decode(adata, adataend, ax, ac, ac=false);
                if (bx <= cx)
		    rp_check_decode(runs, eruns, y, bx, bc, bc=false);
                cx2 = min(ax,bx);
                cc = ac || bc;
                if (cx2 >= ARCH_MAX_UINT)       
                    break;
                if (cc != lastcc) {             
                    if (lastcc) {
                        xmin = min(xmin, lastcx);
                        xmax = max(xmax, cx-1);
                    }
                    rl_encode(cdata, cx-lastcx); /*ENCODEC*/
                    lastcc = !lastcc;
                    lastcx = cx;
                }                               
            }                                   
            if (lastcc && cx>lastcx) {          
                xmin = min(xmin, lastcx);
                xmax = max(xmax, cx-1);
                rl_encode(cdata, cx-lastcx); /*ENCODEC*/
            }                                   
        }
        /* update bounding box */
	if (xmin <= xmax) {
	    c->ymin = min(c->ymin, y);
	    c->ymax = max(c->ymax, y);
	    c->xmin = min(c->xmin, xmin);
	    c->xmax = max(c->xmax, xmax);
	}
        /* fill rows array */
	if (c->ymin <= c->ymax)
	    c->rows[y - c->ymin + 1] = cdata - c->data;
        ASSERT(cdata <= c->data + c->dlen);
    }    
    /* finish */
    return runmap_finish(mem, c, a, 0, del, out);
}

/* Compute bitwise OR of two runmaps. */
int
runmap_or(p2mem *mem, runmap *a, runmap *b, 
	  int del, runmap **out)
{
    int y;
    int ymin, ymax, dlen;
    runmap *c = 0;
    byte *cdata;
    int code;
    /* determine ymin ymax dlen */
    if (! a) return runmap_finish(mem, b, a, b, del, out);
    if (! b) return runmap_finish(mem, a, a, b, del, out);
    ymin = min(a->ymin, b->ymin);
    ymax = max(a->ymax, b->ymax);
    dlen = a->dlen + b->dlen + 4*(ymax-ymin);
    /* allocate runmap */
    code = runmap_alloc(mem, dlen, ymax-ymin+2, &c);
    if (code < 0) return code;
    c->xmin = min(a->xmin, b->xmin);
    c->xmax = max(a->xmax, b->xmax);
    cdata = c->data;
    /* loop over lines */
    for (y=ymin; y<=ymax; y++) {
        uint xmin = ARCH_MAX_UINT;
        uint xmax = 0;
        byte *adata = 0;
        byte *adataend = 0;
        byte *bdata = 0;
        byte *bdataend = 0;
        /* access rows */
        if (y >= a->ymin && y <= a->ymax) {
            adata = a->data + a->rows[y - a->ymin];
            adataend = a->data + a->rows[y - a->ymin + 1];
        }
        if (y >= b->ymin && y <= b->ymax) {
            bdata = b->data + b->rows[y - b->ymin];
            bdataend = b->data + b->rows[y - b->ymin + 1];
        }
        /* process row */
        if (bdata >= bdataend) {
            /* nothing in b */
            if (adata < adataend) {
                memcpy(cdata, adata, adataend-adata);
                cdata += adataend - adata;
		xmin = a->xmin;
		xmax = a->xmax;
            }
        } else if (adata >= adataend) {
            /* nothing in a */
            memcpy(cdata, bdata, bdataend-bdata);
            cdata += bdataend - bdata;
	    xmin = b->xmin;
	    xmax = b->xmax;
        } else {
            /* general case */
            uint ax, bx, cx, cx2, lastcx;
	    bool ac, bc, cc, lastcc;
            ax = bx = cx = cx2 = lastcx = 0;
	    ac = bc = cc = lastcc = false;
	    rl_decode(adata, ax);
	    rl_decode(bdata, bx);
	    /* loop */
            for(;;) {
                cx = cx2;
                if (ax <= cx) 
		    rl_check_decode(adata, adataend, ax, ac, ac=false);
                if (bx <= cx) 
		    rl_check_decode(bdata, bdataend, bx, bc, bc=false);
                cx2 = min(ax,bx);
                cc = ac || bc;
                if (cx2 >= ARCH_MAX_UINT)       
                    break;
                if (cc != lastcc) {             
                    if (lastcc) {
                        xmin = min(xmin, lastcx);
                        xmax = max(xmax, cx-1);
                    }
                    rl_encode(cdata, cx-lastcx); /*ENCODEC*/
                    lastcc = !lastcc;
                    lastcx = cx;
                }                               
            }                                   
            if (lastcc && cx>lastcx) {          
                xmin = min(xmin, lastcx);
                xmax = max(xmax, cx-1);
                rl_encode(cdata, cx-lastcx); /*ENCODEC*/
            }                                   
        }
        /* update bounding box */
	if (xmin <= xmax) {
	    c->ymin = min(c->ymin, y);
	    c->ymax = max(c->ymax, y);
	    c->xmin = min(c->xmin, xmin);
	    c->xmax = max(c->xmax, xmax);
	}
        /* fill rows array */
	if (c->ymin <= c->ymax)
	    c->rows[y - c->ymin + 1] = cdata - c->data;
        ASSERT(cdata <= c->data + c->dlen);
    }
    /* finish */
    return runmap_finish(mem, c, a, b, del, out);
}

/* Compute bitwise AND of two runmaps. */
int
runmap_and(p2mem *mem, runmap *a, runmap *b, 
	   int del, runmap **out)
{
    int y;
    int ymin, ymax, dlen;
    runmap *c = 0;
    byte *cdata;
    int code;
    /* determine ymin ymax dlen */
    if (!a || !b) 
        return runmap_finish(mem, 0, a, b, del, out);
    ymin = max(a->ymin, b->ymin);
    ymax = min(a->ymax, b->ymax);
    if (ymin > ymax || a->xmin > b->xmax || a->xmax < b->xmin) 
        return runmap_finish(mem, 0, a, b, del, out);        
    dlen = 4 * (ymax - ymin);
    dlen += a->rows[ymax + 1 - a->ymin] - a->rows[ymin - a->ymin];
    dlen += b->rows[ymax + 1 - b->ymin] - b->rows[ymin - b->ymin];
    /* allocate runmap */
    code = runmap_alloc(mem, dlen, ymax-ymin+2, &c);
    if (code < 0) return code;
    c->xmin = ARCH_MAX_UINT;
    c->xmax = 0;
    cdata = c->data;
    /* loop over lines */
    for (y=ymin; y<=ymax; y++) {
        uint xmin = ARCH_MAX_UINT;
        uint xmax = 0;
        /* access rows */
        byte *adata = a->data + a->rows[y - a->ymin];
        byte *adataend = a->data + a->rows[y - a->ymin + 1];
        byte *bdata = b->data + b->rows[y - b->ymin];
        byte *bdataend = b->data + b->rows[y - b->ymin + 1];
        /* process row */
        if (bdata < bdataend && adata < adataend) {
            /* something in both rows a and b */
            uint ax = 0;
            uint bx = 0;
            uint cx = 0;
            uint cx2 = 0;
            bool ac = true;
            bool bc = true;
            uint cc = false;
            uint lastcx = 0;
            uint lastcc = false;
            for(;;) {
                cx = cx2;
                if (ax <= cx) 
		    rl_check_decode(adata, adataend, ax, ac, ac=false);
                if (bx <= cx) 
		    rl_check_decode(bdata, bdataend, bx, bc, bc=false);
                cx2 = min(ax,bx);
                cc = ac && bc;
                if (ax >= ARCH_MAX_UINT || bx >= ARCH_MAX_UINT)       
                    break;
                if (cc != lastcc) {             
                    if (lastcc) {
                        xmin = min(xmin, lastcx);
                        xmax = max(xmax, cx-1);
                    }
                    rl_encode(cdata, cx-lastcx); /*ENCODEC*/
                    lastcc = !lastcc;
                    lastcx = cx;
                }                               
            }                                   
            if (lastcc && cx>lastcx) {          
                xmin = min(xmin, lastcx);
                xmax = max(xmax, cx-1);
                rl_encode(cdata, cx-lastcx); /*ENCODEC*/
            }                                   
        }
        /* update bounding box */
	if (xmin <= xmax) {
	    c->ymin = min(c->ymin, y);
	    c->ymax = max(c->ymax, y);
	    c->xmin = min(c->xmin, xmin);
	    c->xmax = max(c->xmax, xmax);
	}
        /* fill rows array */
	if (c->ymin <= c->ymax)
	    c->rows[y - c->ymin + 1] = cdata - c->data;
        ASSERT(cdata <= c->data + c->dlen);
    }
    /* finish */
    return runmap_finish(mem, c, a, b, del, out);
}

/* Bitwise subtraction of runmaps. */
int
runmap_andnot(p2mem *mem, runmap *a, runmap *b, 
	      int del, runmap **out)
{
    int y;
    int ymin, ymax, dlen;
    runmap *c = 0;
    byte *cdata;
    int code;
    /* determine ymin ymax dlen */
    if (! a) return runmap_finish(mem, 0, a, b, del, out);
    if (! b) return runmap_finish(mem, a, a, b, del, out);
    ymin = max(a->ymin, b->ymin);
    ymax = min(a->ymax, b->ymax);
    if (ymin > ymax || b->xmin > a->xmax || b->xmax < a->xmin  )
        return runmap_finish(mem, a, a, b, del, out);        
    dlen = a->dlen + 4 * (ymax - ymin);
    dlen += b->rows[ymax + 1 - b->ymin] - b->rows[ymin - b->ymin];
    ymin = a->ymin;
    ymax = a->ymax;
    /* allocate runmap */
    code = runmap_alloc(mem, dlen, ymax-ymin+2, &c);
    if (code < 0) return code;
    c->xmin = ARCH_MAX_UINT;
    c->xmax = 0;
    cdata = c->data;
    /* loop over lines */
    for (y=ymin; y<=ymax; y++) {
        uint xmin = ARCH_MAX_UINT;
        uint xmax = 0;
        /* access rows */
        byte *adata = a->data + a->rows[y - a->ymin];
        byte *adataend = adataend = a->data + a->rows[y - a->ymin + 1];
        byte *bdata = 0;
        byte *bdataend = 0;
        if (y >= b->ymin && y <= b->ymax) {
            bdata = b->data + b->rows[y - b->ymin];
            bdataend = b->data + b->rows[y - b->ymin + 1];
        }
        /* process */
        if (bdata >= bdataend ) {
            /* nothing in b */
            if (adata < adataend) {
                uint ax = 0;
                memcpy(cdata, adata, adataend-adata);
                cdata += adataend - adata;
		rl_decode(adata, ax);
		xmin = xmax = ax;
		for (;;) {
		    if (adata>=adataend) break;
                    rl_decode(adata, ax);
		    xmax = ax-1;
		    if (adata>=adataend) break;
                    rl_decode(adata, ax);
		}
            }
        } else if (adata >= adataend) {
            /* nothing in a */
        } else {
            /* general case */
            uint ax = 0;
            uint bx = 0;
            uint cx = 0;
            uint cx2 = 0;
            bool ac = true;
            bool bc = true;
            uint cc = false;
            uint lastcx = 0;
            uint lastcc = false;
            for(;;) {
                cx = cx2;
                if (ax <= cx) 
		    rl_check_decode(adata, adataend, ax, ac, ac=false);
                if (bx <= cx) 
		    rl_check_decode(bdata, bdataend, bx, bc, bc=false);
                cx2 = min(ax,bx);
                cc = ac && !bc;
                if (ax >= ARCH_MAX_UINT)
                    break;
                if (cc != lastcc) {             
                    if (lastcc) {
                        xmin = min(xmin, lastcx);
                        xmax = max(xmax, cx-1);
                    }
                    rl_encode(cdata, cx-lastcx); /*ENCODEC*/
                    lastcc = !lastcc;
                    lastcx = cx;
                }                               
            }                                   
            if (lastcc && cx>lastcx) {          
                xmin = min(xmin, lastcx);
                xmax = max(xmax, cx-1);
                rl_encode(cdata, cx-lastcx); /*ENCODEC*/
            }                                   
        }
        /* update bounding box */
	if (xmin <= xmax) {
	    c->ymin = min(c->ymin, y);
	    c->ymax = max(c->ymax, y);
	    c->xmin = min(c->xmin, xmin);
	    c->xmax = max(c->xmax, xmax);
	}
        /* fill rows array */
	if (c->ymin <= c->ymax)
	    c->rows[y - c->ymin + 1] = cdata - c->data;
        ASSERT(cdata <= c->data + c->dlen);
    }
    /* finish */
    return runmap_finish(mem, c, a, b, del, out);
}

/* Compute area and perimeter of runmap. */
void
runmap_info(runmap *r, int *parea, int *pperimeter)
{
    int y, nrun, area, canc;
    byte *pdata, *pdataend;
    byte *data, *dataend;
    /* check */
    nrun = area = canc = 0;
    if (r && r->rows && r->data && r->ymax>=r->ymin) {
        /* haffner's computation of perimeter */
        pdataend = r->data;
        dataend = r->data;
        for (y=r->ymin; y<=r->ymax; y++) {
            int x = 0;
            int x1 = 0;
            int px = 0;
            int px1 = 0;
            pdata = pdataend;
            pdataend = data = dataend;
            dataend = r->data + r->rows[y - r->ymin + 1];
            while (data < dataend) {
                rl_decode(data, x);
                if (data >= dataend) 
                    break;
                x1 = x;
                rl_decode(data, x);
                nrun += 1;
                area += x - x1;
                while (px1 < x)
                {
                    if (px > x1) { 
                        canc += min(x,px) - max(x1,px1);
                        if (px >= x)
                            break;
                    }
                    if (pdata >= pdataend) 
                        break;
                    rl_decode(pdata, px);
                    if (pdata >= pdataend) 
                        break;
                    px1 = px;
                    rl_decode(pdata, px);
                }
            }
        }
    }
    if (parea)
        *parea = area;
    if (pperimeter)
        *pperimeter = 2*(nrun+area-canc);
}

/* Save a runmap as PBM */
int
runmap_save(runmap *r, FILE *f, 
            uint xmin, uint xmax, uint ymin, uint ymax, 
            const char *comment)
{
    uint w = xmax - xmin + 1;
    uint h = ymax - ymin + 1;
    uint rowsize;
    byte *buf;
    uint y;
    rowsize = (w+7)/8;
    if (w<=0 || h<=0) return_error(gs_error_limitcheck);
    buf = p2mem_parent_alloc(rowsize);
    if (! buf) return_VMerror;
    /* PBM files begin with a header line "P4 <width> <height>\n"
       indicating the bitmap size.  The rest of the file encodes 
       the rows as a packed bitmap.  Each row occupies an integral
       number of byte.  The most significant bit of a byte represents
       the leftmost pixel coded by that byte. */
    fprintf(f,"P4\n");
    if (comment) 
        fprintf(f, "# %s\n", comment);
    fprintf(f,"%d %d\n", w, h);
    for (y=ymin; y<=ymax; y++) {
        uint x = xmin;
        uint nx = 0;
        int z = 0;
        int m = 0x80;
        byte *ptr = buf;
        bool c = true;
        byte *data = 0;
        byte *dataend = 0;
        if (r && y>=r->ymin && y<=r->ymax) {
            data = r->data + r->rows[y - r->ymin];
            dataend = r->data + r->rows[y - r->ymin + 1];
        }
        while (nx<=xmax) {
            rl_check_decode(data, dataend, nx, c, c=false);
            nx = min(xmax+1, nx);
            while (x < nx) {
                if (c) {
                    while (x<nx && m) { x++; z|=m; m>>= 1; } 
                } else {
                    while (x<nx && m) { x++; m>>= 1; } 
                }
                if (! m) {
                    *ptr++ = z;
                    z = (c ? 0xff : 0x00);
                    while (x+8<=nx) { x+=8; *ptr++ = z; }
                    z = 0x00;
                    m = 0x80;
                }
            }
        }
        if (m < 0x80)
            *ptr++ = z;
        ASSERT(ptr == buf+rowsize);
        if (fwrite(buf, 1, rowsize, f) != rowsize) {
            p2mem_parent_free(buf);
            return_error(gs_error_ioerror);
        }
    }
    p2mem_parent_free(buf);
    return 0;
}

/* Draws a runmap with a specified color into a raster pixmap.  
   Raster covers rectangle CWxCH+CX+CY. Pointer BASE indicates
   position (CX,CY).  Integer SRASTER represents the pointer
   difference from one line to the next. */
void
runmap_play(runmap *r, gx_color_index color,
            byte *base, int sraster, uint cx, uint cy, uint cw, uint ch)
{
    byte c[3];
    uint cx2 = cx + cw;
    uint cy2 = cy + ch;
    c[0] = color >> 16;
    c[1] = color >> 8;
    c[2] = color;
    if (r) {
        uint y1 = max(cy, r->ymin);
        uint y2 = min(cy2, r->ymax + 1);
        byte *p = base + (y1 - cy) * sraster - cx;
        while (y1 < y2) {
            byte *data = r->data + r->rows[y1 - r->ymin];
            byte *dataend = r->data + r->rows[y1 - r->ymin + 1];
            if (data < dataend) {
                uint x = 0;
                while (data < dataend) {
                    rl_decode(data, x);
                    if (data < dataend && x < cx2) {
                        uint x1 = x;
                        rl_decode(data, x);
                        if (x > cx) {
                            byte *p1 = p + 3 * max(x1, cx);
                            byte *p2 = p + 3 * min(x, cx2);
                            while (p1 < p2) {
                                *p1++ = c[0];
                                *p1++ = c[1];
                                *p1++ = c[2];
                            }
                        }
                    }
                }
            }
            y1 += 1;
            p += sraster;
        }
    }    
}



/* ======================================
            R U N M A P B L D
   ====================================== */

/* This allows the efficient construction of rmap using arbitrarily ordered
   black runs.  Each black run is added using runmapbld_write() and extends
   from column x1 to x2 (inclusive) on row y.  Runs are stored in a temporary
   buffer and ORed into the current runmap.  The final runmap is computed when
   runmapbld_close() is called. */

/* Create a runmap builder. */
int
runmapbld_open(p2mem *mem, uint nrunsmax, runmapbld **out)
{
    runmapbld *c = p2mem_alloc(mem, sizeof(runmapbld));
    runptr r = p2mem_alloc(mem, sizeof(uint)*3*nrunsmax);
    if (! (c && r)) return_VMerror;
    c->mem = mem;
    c->rmap = 0;
    c->runs = r;
    c->nruns = 0;
    c->nrunsmax = nrunsmax;
    c->needsort = false;
    *out = c;
    return 0;
}

/* Internal: qsort callback for ordering runs. */
private int 
runmapbld_sortsub(const void *av, const void *bv)
{
    const int *a = (const uint*)av;
    const int *b = (const uint*)bv;
    return a[0]!=b[0] ? a[0]-b[0] : a[1]!=b[1] ? a[1]-b[1] : a[2]-b[2];
}

/* Compute up-to-date runmap. */
int
runmapbld_flush(runmapbld *bld)
{
    int code = 0;
    if (bld->needsort && bld->nruns>1) {
        int i,j;
        int nruns = bld->nruns;
        runptr runs = bld->runs;
        qsort(runs, nruns, sizeof(int[3]), runmapbld_sortsub);
        for (i=1,j=0; i<nruns; i++) {
            if (runs[i][0]==runs[j][0] && runs[i][1]<=runs[j][2]+1) {
                runs[j][2] = max(runs[i][2],runs[j][2]);
            } else {
                j += 1; 
                runs[j][0]=runs[i][0]; 
                runs[j][1]=runs[i][1]; 
                runs[j][2]=runs[i][2]; 
            }
        }
        bld->nruns = j+1;
    }
    if (bld->nruns > 0)
        code = runmap_or_runs(bld->mem, bld->rmap, bld->runs, bld->nruns, 
			      1, &bld->rmap);
    bld->nruns = 0;
    bld->needsort = false;
    return code;
}

/* Add run {y,x1,x2} to the runmap builder. */
int 
runmapbld_write(runmapbld *bld, int y, int x1, int x2)
{
    uint *lastrun;
    if (bld->nruns > 0) {
	lastrun = bld->runs[bld->nruns-1];
        if (lastrun[0] == y) {
            if (x1 < lastrun[1])
                bld->needsort = true;
            if (lastrun[1]<=x2+1 && lastrun[2]+1>=x1) {
                lastrun[1] = min(x1, lastrun[1]);
                lastrun[2] = max(x2, lastrun[2]);
                return 0;
            }
        } else if (y<lastrun[0])
            bld->needsort = true;
    }            
    if (bld->nruns >= bld->nrunsmax) {
        int code = runmapbld_flush(bld);
        if (code < 0) return code;
    }
    lastrun = bld->runs[bld->nruns++];
    lastrun[0] = y;
    lastrun[1] = x1;
    lastrun[2] = x2;
    return 0;
}

/* Destroy runmap builder, release memory, and return runmap. */
int 
runmapbld_close(runmapbld *bld, runmap **out)
{
    if (bld) {
        if (out) {
            int code = runmapbld_flush(bld);
            if (code < 0) return code;
            *out = bld->rmap;
            bld->rmap = 0;
        }
        runmap_free(bld->rmap);
        p2mem_free(bld->mem, bld->runs);
        p2mem_free(bld->mem, bld);
        return 0;
    }
    if (out) 
        *out = 0;
    return 0;
}

/* Accumulate a rectangle into a runmapbld */
int
runmapbld_put_rect(runmapbld *bld,
                   int xx, int yy, int w, int h)
{
    int y;
    int code = 0;
    for (y=0; y<h; y++)
        if ((code = runmapbld_write(bld, yy+y, xx, xx+w-1)) < 0)
            return code;
    return 0;
}

/* Accumulate a bitmap into a runmapbld */
int
runmapbld_put_bitmap(runmapbld *bld,
                     const byte *base, int sourcex, int sraster, int xor,
                     int xx, int yy, int w, int h)
{
    int y;
    int code = 0;
    int basemask = 0x80 >> (sourcex & 0x7);
    base = base + (sourcex >> 3);
    for (y=0; y<h; y++, base+=sraster) {
        const byte *row = base;
        int z = (*row++) ^ xor;
        int m = basemask;
        int x1 = 0;
        int x = 0;
        while (x < w) {
            while (x < w) {
                if (m) {
                    if (z & m)
                        break;
                    x += 1;
                    m >>= 1;
                } else {
                    z = (*row++) ^ xor;
                    while (z==0x00 && x+7<w) {
                        z = (*row++) ^ xor;
                        x += 8;
                    }
                    m = 0x80;
                }
            }
            x1 = x;
            while (x < w) {
                if (m) {
                    if (! (z & m))
                        break;
                    x += 1;
                    m >>= 1;
                } else {
                    z = (*row++) ^ xor;
                    while (z==0xff && x+7<w) {
                        z = (*row++) ^ xor;
                        x += 8;
                    }
                    m = 0x80;
                }
            }
            if (x > x1)
                if ((code = runmapbld_write(bld, yy+y, xx+x1, xx+x-1)) < 0)
                    return code;
        }
    }
    return 0;
}




/* ======================================
           H A S H   T A B L E
      A N D   A P P L I C A T I O N S
   ====================================== */

/* Internal: change the number of buckets. */
private int
htable_reorganize(htable *h, int nbuckets)
{
    int b;
    int oldnbuckets = h->nbuckets;
    void **oldbuckets = h->buckets;
    void **buckets = p2mem_alloc(h->mem, nbuckets*sizeof(void*));
    if (! buckets) return_VMerror;
    memset(buckets, 0, nbuckets*sizeof(void*));
    h->nbuckets = nbuckets;
    h->buckets = buckets;
    for (b=0; b<oldnbuckets; b++) {
	void *e = oldbuckets[b];
	while (e) {
	    htablelink *f = (htablelink*)((char*)e + h->xsize);
	    void *enext = f->next;
	    int nb = f->hash % nbuckets;
	    f->next = buckets[nb];
	    buckets[nb] = e;
	    e = enext;
	}
    }
    p2mem_free(h->mem, oldbuckets);
    return 0;
}

/* Create a hash table. */
htable *
htable_alloc(p2mem *mem, int payloadsize)
{
    int a;
    htable *h = p2mem_alloc(mem, sizeof(htable));
    if (h) {
	memset(h, 0, sizeof(htable));
	h->mem = mem;
	h->psize = payloadsize;
	/* compute alignment of htablelink */
	a = ((int)&(((struct{char pad; htablelink e;}*)0)->e));
	/* compute offset of htablelink w.r.t. payload */
	h->xsize = (int)((payloadsize + a - 1) / a) * a;
	/* setup initial bucket table */
	if (htable_reorganize(h, 17) >= 0)
	    return h;
    }
    /* allocation failed */
    p2mem_free(mem, h);
    return 0;
}

/* Destroy a hash table */
void
htable_free(htable *h) 
{
    if (h) {
	int b;
	for (b=0; b<h->nbuckets; b++) {
	    void *e = h->buckets[b];
	    while (e) {
		htablelink *f = (htablelink*)((char*)e + h->xsize);
		void *enext = f->next;
		if (h->payload_release) 
		    h->payload_release(h->mem, e);
		p2mem_free(h->mem, e);
		e = enext;
	    }
	}
	p2mem_free(h->mem, h->buckets);
	p2mem_free(h->mem, h);
    }
}

/* Internal: helper for htable_lookup() */
private void *
htable_new_entry(htable *h, const void *key, 
                 int keysize, uint hash, int bucket)
{
    int esize = h->xsize + sizeof(htablelink);
    htablelink *f;
    void *e;
    if (h->nelems*3 > h->nbuckets*2)
        if (htable_reorganize(h, 2 * h->nbuckets - 1) >= 0)  
            bucket = hash % h->nbuckets;
    if (! (e = p2mem_alloc(h->mem, esize)))
        return 0;
    memset(e, 0, esize);
    if (h->key_copy) 
        (*h->key_copy)(h->mem, e, key);
    else 
        memcpy(e, key, keysize);
    f = ((htablelink*)((char*)e + h->xsize));
    f->hash = hash;
    f->next = h->buckets[bucket];
    h->buckets[bucket] = e;
    h->nelems += 1;
    return e;
}

/* Internal: helper for htable_lookup() */
void *
htable_lookup_sub(htable *h, const void *key, 
                  int keysize, uint hash, bool create)
{
    int bucket = hash % h->nbuckets;
    void *e = h->buckets[bucket];
    if (h->key_equal) {
	while (e && !h->key_equal(e, key))
	    e = ((htablelink*)((char*)e + h->xsize))->next;
    } else {
	while (e && memcmp(e, key, keysize))
	    e = ((htablelink*)((char*)e + h->xsize))->next;
    }
    if (!e && create)
        e = htable_new_entry(h, key, keysize, hash, bucket);
    return e;
}




/* ======================================
    C O L O R   Q U A N T I Z A T I O N
   ====================================== */


/* Add contribution to the histogram */
int
colorhash_add(htable *colorhash, gx_color_index color, uint w)
{
    colordata *cd;
    if (! (cd = htable_lookup(colorhash, &color, hash_rgb(color), true)))
        return_VMerror;
    cd->w += w;
    return 0;
}

/* Reference for the median color quantization algorithm: Paul
   Heckbert: "Color Image Quantization for Frame Buffer Display",
   SIGGRAPH '82 Proceedings, page 297.  Also used in ppmquant. */

/* Internal: Colorspace box for quantizer */
typedef struct colorbox_s { 
    struct colorbox_s *next;
    colordata *cdata;
    int ndata; 
    int w; 
} colorbox;

/* Internal: sorting direction mask */
private gx_color_index colorcomp_dir; 

/* Internal: sorting subroutine */
private int
colorcomp_sub(const void *pa, const void *pb)
{
    gx_color_index a = colorcomp_dir & *(gx_color_index*)pa;
    gx_color_index b = colorcomp_dir & *(gx_color_index*)pb;
    return a - b;
}

/* Reduce number of colors.*/
int 
color_quantize(p2mem *mem, htable *colorhash, uint maxcolors,
               gx_color_index **ppalette, uint *psize)
{ 
    /* Variables */
    int code;
    gx_color_index *palette = 0;
    colordata *cdata = 0;
    colorbox  *cbox = 0;
    colorbox *cb;
    colorbox **pcb;
    colordata *cd;
    int ncolors;
    int w;
    int i;
    /* Copy histogram in cdata array */
    cdata = p2mem_alloc(mem, sizeof(colordata)*colorhash->nelems);
    if (!cdata) goto exitmem;
    w = 0;
    ncolors = 0;
    htable_begin_loop(cd, colorhash) {
	cdata[ncolors++] = cd[0];
	w += cd->w;
    } htable_end_loop(cd, colorhash);
    /* Create first quantization box */
    cbox = p2mem_alloc(mem, sizeof(colorbox));
    if (!cbox) goto exitmem;
    cbox->next = 0;
    cbox->cdata = cdata;
    cbox->ndata = ncolors;
    cbox->w = w;
    ncolors = 1;
    /* Median color quantization */
    while (ncolors < maxcolors) {
	int rl,bl,gl;
	byte pmin[3], pmax[3];
	colorbox *ncb;
	/* Find suitable box */
	for (pcb=&cbox; *pcb; pcb=&((*pcb)->next))
	    if ((*pcb)->ndata>=2)
		break;
	/* Unlink box or exit loop */
	if (! (cb = *pcb)) break;
	*pcb = cb->next;
	/* Compute box boundaries */
	pmin[0]=pmin[1]=pmin[2]=0xff;
	pmax[0]=pmax[1]=pmax[2]=0x00;
	cd = cb->cdata;
	for (i=0; i<cb->ndata; i++) {
	    gx_color_index color = cb->cdata[i].color;
	    byte r=(color>>16), g=(color>>8), b=(color);
	    pmin[0] = min(pmin[0],r);
	    pmin[1] = min(pmin[1],g);
	    pmin[2] = min(pmin[2],b);
	    pmax[0] = max(pmax[0],r);
	    pmax[1] = max(pmax[1],g);
	    pmax[2] = max(pmax[2],b);
	}
	rl = pmax[0] - pmin[0];
	gl = pmax[1] - pmin[1];
	bl = pmax[2] - pmin[2];
	/* Determine split direction */
	if (gl>=bl && gl>=rl)
	    colorcomp_dir = 0x00ff00;
	else if (rl>=gl && rl>=bl)
	    colorcomp_dir = 0xff0000;
	else 
	    colorcomp_dir = 0x0000ff;
	/* Sort colordata and find median */
	qsort(cb->cdata, cb->ndata, sizeof(colordata), colorcomp_sub);
	for (i=w=0; i<cb->ndata-1 && w+w<cb->w; i++) 
	    w += cb->cdata[i].w;
	/* Prepare new boxes */
	ncolors += 1;
	ncb = p2mem_alloc(mem, sizeof(colorbox));
	if (!ncb) goto exitmem;
	ncb->cdata = cb->cdata + i;
	ncb->ndata = cb->ndata - i;
	ncb->w = cb->w - w;
	cb->ndata = i;
	cb->w = w;
	/* Insert cb at proper location */
	pcb = &cbox;
	while (*pcb && (*pcb)->w >= cb->w)
	    pcb = &((*pcb)->next);
	cb->next = *pcb;
	*pcb = cb;
	/* Insert ncb at proper location */
	pcb = &cbox;
	while (*pcb && (*pcb)->w >= ncb->w)
	    pcb = &((*pcb)->next);
	ncb->next = *pcb;
	*pcb = ncb;
    }
    /* Allocate and fill palette */
    palette = p2mem_alloc(mem, ncolors*sizeof(gx_color_index));
    if (! palette) goto exitmem;
    *ppalette = palette;
    *psize = ncolors;
    ncolors = 0;
    for (cb=cbox; cb; cb=cb->next) {
	/* Compute mean color */
	byte r, g, b;
	double rsum, gsum, bsum;
	rsum = gsum = bsum = 0;
	for (i=0; i<cb->ndata; i++) {
	    gx_color_index color = cb->cdata[i].color;
	    w = cb->cdata[i].w;
	    rsum += (double)w * (double)(0xff & (color >> 16));
	    gsum += (double)w * (double)(0xff & (color >> 8));
	    bsum += (double)w * (double)(0xff & color);
	    cd = htable_lookup(colorhash, &color, hash_rgb(color), false);
	    cd->w = ncolors; /* Color hash now gives palette indice */
	}
	r = max(0, min(255, (int)(rsum/cb->w)));
	g = max(0, min(255, (int)(gsum/cb->w)));
	b = max(0, min(255, (int)(bsum/cb->w)));
	palette[ncolors] = (r<<16)|(g<<8)|(b);
	ncolors += 1;
    }
    /* Success */
    code = 0;
    goto exit;
 exitmem:
    /* Memory error */
    code = gs_note_error(gs_error_VMerror);
 exit:
    /* Free everything and return */
    p2mem_free(mem, cdata);
    while (cbox) {
	cb = cbox->next;
	p2mem_free(mem, cbox);
	cbox = cb;
    }
    return code;
}



/* ======================================
               C H R O M E
   ====================================== */

/* Some image components do not have a single color.  These components are
   normally classified as background.  In order to generate the background
   image, we need to record additional information besides the shape of the
   object.  This is stored as a sequence of rendering opcodes that can be
   replayed at later times.  Chrome data is moslty accessed sequentially.  It
   is stored in a linked list of data blocks and accessed like a file.  Using
   the ghostscript clist infrastructure might have been smarter. */

/* Internal: length of a chrome block */
#define chrome_block_len (p2mem_max - 8)

/* Internal: chrome blocks */
typedef struct chrome_block_s {
    struct chrome_block_s *next;
    byte data[chrome_block_len];
} chrome_block;

/* Chrome data */
struct chrome_s {
    p2mem *mem;            /* Block memory */
    chrome_block *first;   /* Block chain  */
    chrome_block *last;    /* Current block for writing */
    byte *wpos;            /* Current pointer for writing */
    byte *wend;            /* Pointer to end of current block */
    byte *wlastrect;       /* Position following last rectangle opcode */
    int x, sx, y, sy;      /* Opcode context */
    int w, h;              /* Opcode context */
    gx_color_index c0, c1; /* Opcode context */
};

/* Internal: reset opcode context */
#define chrome_reset_ctx(ctx) { \
    (ctx)->x = (ctx)->sx = (ctx)->y = (ctx)->sy = 0; \
    (ctx)->w = (ctx)->h = 1; (ctx)->c0 = (ctx)->c1 = 0; }

/* Allocate chrome */
chrome *
chrome_create(void)
{
    p2mem *nmem = p2mem_create();
    chrome *cr = 0;
    if (nmem) {
        cr = p2mem_alloc(nmem, sizeof(chrome));
        if (cr) {
            memset(cr, 0, sizeof(chrome));
            cr->mem = nmem;
            chrome_reset_ctx(cr);
            return cr;
        }
        p2mem_destroy(nmem);
    }
    return 0;
}

/* Destroy chrome */
void
chrome_destroy(chrome *cr)
{
    if (cr != 0) 
        p2mem_destroy(cr->mem);
}

/* Data structure recording current chrome position */
struct chrome_pos_s {
    chrome_block *block;  /* Stored block pointer */
    byte *pos;            /* Stored position pointer */
    int len;              /* Length of chrome data (-1 if unknown) */
};

/* Create a chrome_pos */
chrome_pos *
chrome_getpos(chrome *cr)
{
    /* Allocation is controlled by the chrome object */
    chrome_pos *cp = p2mem_alloc(cr->mem, sizeof(chrome_pos));
    if (!cp) return 0;
    cp->block = cr->last;
    cp->pos = cr->wpos;
    cp->len = -1;
    return cp;
}

/* Close chrome_pos object */
void
chrome_closepos(chrome *cr, chrome_pos *cpos)
{
    /* Insert an end-of-object opcode */
    private int chrome_put_end(chrome *cr);
    chrome_put_end(cr);
    /* Fix block and pos */
    if (!cpos->block) {
        cpos->block = cr->first;
        cpos->pos = cr->first->data;
    }
    /* Compute length */
    if (cpos->block == cr->last) {
        cpos->len = cr->wpos - cpos->pos;
    } else {
        chrome_block *b = cpos->block;
        cpos->len = chrome_block_len - (cpos->pos - b->data);
        while ((b = b->next) != cr->last)
            cpos->len += chrome_block_len;
        cpos->len += cr->wpos - b->data;
    }
}

/* Internal: opcodes */
enum chrome_opcodes {
    /* minor opcodes */
    op_end          = 0x01,  /* -- end of object       */
    op_pixmap       = 0x02,  /* -- followed by pixmap data */
    op_set_c0       = 0x03,  /* -- followed by r,g,b */
    op_set_c1       = 0x04,  /* -- followed by r,g,b */
    op_rest_x       = 0x05,  /* -- x = sx */
    op_rest_y       = 0x06,  /* -- y = sy */
    /* short opcodes */
    op_rect         = 0x10,  /* low nibble is repeat count, followed by r,g,b */
    op_add_x_short  = 0x30,  /* low nibble is positive x-offset */
    op_add_y_short  = 0x60,  /* low nibble is positive y-offset */
    op_set_w_short  = 0x90,  /* low nibble is small w */
    op_set_h_short  = 0xB0,  /* low nibble is small h */
    op_run_c0_short = 0xD0,  /* low nibble is run length */
    op_run_c1_short = 0xF0,  /* low nibble is run length */
    /* long opcodes */
    op_add_x        = 0x20,  /* argument is formed by using */
    op_add_y        = 0x50,  /* ... low nibble and the next */
    op_sub_x        = 0x40,  /* ... two bytes. */
    op_sub_y        = 0x70,  /* ... */
    op_set_w        = 0x80,  /* ... */
    op_set_h        = 0xA0,  /* ... */
    op_run_c0       = 0xC0,  /* ... */
    op_run_c1       = 0xE0   /* ... */
};

/* Internal: opcode transformation */
#define op_short(op)  (op + 0x10)  /* op_add_N, op_set_N, op_run_C */
#define op_minus(op)  (op + 0x20)  /* op_add_N */

/* --- Encoding subroutines */

/* Internal: append a new block to chrome data */
private chrome_block *
chrome_newblock(chrome *cr)
{
    chrome_block *cb;
    if (! (cb = p2mem_alloc(cr->mem, sizeof(chrome_block))))
        return 0;
    cb->next = 0;
    cr->last ? (cr->last->next = cb) : (cr->first = cb);
    cr->last = cb;
    cr->wpos = cb->data;
    cr->wend = cb->data + chrome_block_len;
    cr->wlastrect = 0;
    return cb;
}

/* Internal: append multiple bytes to chrome data */
private int
chrome_write(chrome *cr, const byte *p, int len)
{
    int nlen;
    while (len > 0) {
        if (cr->wpos >= cr->wend)
            if (! chrome_newblock(cr))
                return_VMerror;
        nlen = min(len, cr->wend - cr->wpos);
        memcpy(cr->wpos, p, nlen);
        cr->wpos += nlen;
        p += nlen;
        len -= nlen;
    }
    return 0;
}

/* Internal: append a byte to chrome data */
#define chrome_putc(cr, b, onerror) { \
  if ((cr)->wpos >= (cr)->wend && !chrome_newblock(cr)) { onerror;} \
  *(cr)->wpos++ = (byte)(b); }

/* Internal: append short opcode */
#define chrome_put_short(cr, op, arg, onerror) { \
   ASSERT((arg)>=1 && (arg)<=0x10); \
   chrome_putc((cr), (byte)(op) + (byte)(arg) - 1, onerror); }

/* Internal: append long opcode */
#define chrome_put_long(cr, op, arg, onerror) { \
   ASSERT((arg)>=0 && (arg)<=0xfffff); \
   chrome_putc((cr), (byte)((arg)>>16) + (byte)(op), onerror); \
   chrome_putc((cr), (byte)((arg)>>8), onerror); \
   chrome_putc((cr), (byte)(arg), onerror); }

/* Internal: append long or short opcode */
#define chrome_put_cmd(cr, op, arg, onerror) { \
   if ((arg)<=0x10 && (arg)>=1) chrome_put_short(cr, op_short(op), arg, onerror) \
   else chrome_put_long(cr, op, arg, onerror) }

/* Internal: append rgb color */
#define chrome_put_rgb(cr, c, onerror) { \
   chrome_putc((cr), (byte)((c)>>16), onerror); \
   chrome_putc((cr), (byte)((c)>>8), onerror); \
   chrome_putc((cr), (byte)(c), onerror); }

/* Internal: put colors */
private int
chrome_put_c0c1(chrome *cr, gx_color_index c0, gx_color_index c1)
{
    if (c0 != gx_no_color_index && cr->c0 != c0) {
        chrome_putc(cr, op_set_c0, return_VMerror);
        chrome_put_rgb(cr, c0, return_VMerror);
        cr->c0 = c0;
    }
    if (c1 != gx_no_color_index && cr->c1 != c1) {
        chrome_putc(cr, op_set_c1, return_VMerror);
        chrome_put_rgb(cr, c1, return_VMerror); 
        cr->c1 = c1;
    }
    return 0;
}

/* Internal: put x y */
private int
chrome_put_xy(chrome *cr, int x, int y)
{
    /* Set X */
    if (x != cr->x) {
        if (x == cr->sx) {
            chrome_putc(cr, op_rest_x, return_VMerror);
        } else if (x > cr->x && x <= cr->x + 0x10) {
            chrome_put_short(cr, op_add_x_short, (x - cr->x), return_VMerror);
        } else if (x > cr->sx && x <= cr->sx + 0x10) {
            chrome_putc(cr, op_rest_x, return_VMerror);
            chrome_put_short(cr, op_add_x_short, (x - cr->sx), return_VMerror);
        } else if (x > cr->x) {
            chrome_put_long(cr, op_add_x, (x - cr->x), return_VMerror);
        } else {
            chrome_put_long(cr, op_sub_x, (cr->x - x), return_VMerror);
            cr->sx = x;
        }
        cr->x = x;
    }
    /* Set Y */
    if (y != cr->y) {
        if (y == cr->sy) {
            chrome_putc(cr, op_rest_y, return_VMerror);
        } else if (y > cr->y && y <= cr->y + 0x10) {
            chrome_put_short(cr, op_add_y_short, (y - cr->y), return_VMerror);
        } else if (y > cr->sy && y <= cr->sy + 0x10) {
            chrome_putc(cr, op_rest_y, return_VMerror);
            chrome_put_short(cr, op_add_y_short, (y - cr->sy), return_VMerror);
        } else if (y > cr->y) {
            chrome_put_long(cr, op_add_y, (y - cr->y), return_VMerror);
        } else {
            chrome_put_long(cr, op_sub_y, (cr->y - y), return_VMerror);
            cr->sy = y;
        }
        cr->y = y;
    }
    return 0;
}

/* Internal: put x y w h */
private int
chrome_put_xywh(chrome *cr, int x, int y, int w, int h)
{
    if (cr->w != w) {
        chrome_put_cmd(cr, op_set_w, w, return_VMerror);
        cr->w = w; 
    }
    if (cr->h != h) {
        chrome_put_cmd(cr, op_set_h, h, return_VMerror);
        cr->h = h;
    }
    return chrome_put_xy(cr, x, y);
}

/* Put end-of-object */
private int
chrome_put_end(chrome *cr)
{
    chrome_putc(cr, op_end, return_VMerror);
    chrome_reset_ctx(cr);
    return 0;
}

/* Put filled rectangle */
int
chrome_put_rect(chrome *cr, int x, int y, int w, int h, gx_color_index c)
{
    int code;
    if (cr->c0 == c && cr->x == x && cr->wpos 
        && cr->wpos == cr->wlastrect + 4
        && cr->y == y && cr->w == w && cr->h == h
        && cr->wlastrect[0] >= op_rect 
        && cr->wlastrect[0] < op_rect + 0xf ) {
        /* Shortcut for adjacent rectangles */
        cr->wlastrect[0] += 1;
        cr->x += w;
        return 0;
    }
    /* Regular code */
    if ((code = chrome_put_xywh(cr, x, y, w, h)) < 0)
        return code;
    cr->wlastrect = cr->wpos;
    chrome_putc(cr, op_rect, return_VMerror);
    chrome_put_rgb(cr, c, return_VMerror);
    /* Setup state */
    cr->x = x + w;
    cr->c0 = c;
    return 0;
}

/* Put monochrome runmap */
int
chrome_put_runmap(chrome *cr, runmap *r, gx_color_index c)
{
    int y;
    int code;
    /* Prepare */
    if (r == 0) 
        return 0;
    if ((code = chrome_put_c0c1(cr, gx_no_color_index, c)) < 0)
        return code; 
    /* Loop on y */
    for (y=r->ymin; y<=r->ymax; y++) {
        byte *data = r->data + r->rows[y - r->ymin];
        byte *dataend = r->data + r->rows[y - r->ymin + 1];
        if (data < dataend) {
            int x = 0;
            /* Set x, y */
            if ((code = chrome_put_xy(cr, 0, y)) < 0)
                return code;
            /* Store runs */
            while (data < dataend) {
                int x1 = x;
                rl_decode(data, x);
                if (data < dataend) {
                    int x2 = x;
                    rl_decode(data, x);
                    if (x2 > x1) 
                        chrome_put_cmd(cr, op_add_x, x2-x1, return_VMerror);
                    if (x > x2) 
                        chrome_put_cmd(cr, op_run_c1, x-x2, return_VMerror);
                }
            }
            cr->x = x;
        }
    }
    return 0;
}

/* Put monochrome bitmap */
int
chrome_put_bitmap(chrome *cr, const byte * base, int sourcex, int sraster,
                  int xx, int yy, int w, int h, 
                  gx_color_index c0, gx_color_index c1)
{
    int y;
    int code;
    int basemask = 0x80 >> (sourcex & 0x7);
    base = base + (sourcex >> 3);
    /* Prepare */
    if ((code = chrome_put_c0c1(cr, c0, c1)) < 0)
        return code;
    /* Loop */
    for (y=yy; y<yy+h; y++, base+=sraster) {
        const byte *row = base;
        int z = (*row++);
        int m = basemask;
        int x1 = 0;
        int x2 = 0;
        int x = 0;
        /* Set x, y */
        if ((code = chrome_put_xy(cr, xx, y)) < 0)
            return code;
        /* Search runs */
        while (x < w) {
            x1 = x;
            while (x < w) {
                if (m) {
                    if (z & m)
                        break;
                    x += 1;
                    m >>= 1;
                } else {
                    z = (*row++);
                    while (z==0x00 && x+7<w) {
                        z = (*row++);
                        x += 8;
                    }
                    m = 0x80;
                }
            }
            x2 = x;
            while (x < w) {
                if (m) {
                    if (! (z & m))
                        break;
                    x += 1;
                    m >>= 1;
                } else {
                    z = (*row++);
                    while (z==0xff && x+7<w) {
                        z = (*row++);
                        x += 8;
                    }
                    m = 0x80;
                }
            }
            /* Write runs */
            if (x2 > x1) {
                if (c0 == gx_no_color_index) {
                    chrome_put_cmd(cr, op_add_x, (x2-x1), return_VMerror);
                } else {
                    chrome_put_cmd(cr, op_run_c0, (x2-x1), return_VMerror);
                }
            }
            if (x > x2) {
                if (c1 == gx_no_color_index) {
                    chrome_put_cmd(cr, op_add_x, (x-x2), return_VMerror);
                } else {
                    chrome_put_cmd(cr, op_run_c1, (x-x2), return_VMerror);
                }
            }
        }
        cr->x = xx + x;
    }
    return 0;
}

/* Put color pixmap */
int
chrome_put_pixmap(chrome *cr, const byte * base, int sourcex, int sraster,
                  int xx, int yy, int w, int h)
{
    int y;
    int code;
    base = base + 3*sourcex;
    /* Prepare */
    if ((code = chrome_put_xywh(cr, xx, yy, w, h)) < 0) 
        return code;
    /* Store opcode */
    chrome_putc(cr, op_pixmap, return_VMerror);
    for (y=0; y<h; y++, base+=sraster) {
        if ((code = chrome_write(cr, base, 3*w)) < 0)
            return code;
    }
    /* Set state after pixmap opcode. */
    cr->x = xx + w;
    cr->sx = xx;
    cr->y = yy;
    return 0;
}

/* --- Decoding subroutines */

/* Internal: Data structure for reading data from chrome */
typedef struct chrome_reader_s {
    /* Reading point */
    chrome_block *block;
    byte *pos;
    byte *end;
} chrome_reader;

/* Internal: Read one byte */
#define chrome_getc(crd) \
    ((crd)->pos < (crd)->end ? *(crd)->pos++ : chrome_getc_sub(crd))

/* Internal: Read one byte, helper subroutine */
private inline byte 
chrome_getc_sub(chrome_reader *crd)
{
    if (!crd->block->next) return 0;
    crd->block = crd->block->next;
    crd->pos = crd->block->data;
    crd->end = crd->pos + chrome_block_len;
    return * crd->pos ++;
}

/* Internal: Read long argument */
#define chrome_getarg(crd, op, argvar) { \
    argvar = ((op & 0xf) << 16) | (chrome_getc(crd) << 8); \
    argvar |= chrome_getc(crd); }

/* Internal: Read bytes */
private inline void
chrome_read(byte *dest, chrome_reader *crd, int len)
{
    while (len > 0) {
        int nlen;
        if (crd->pos >= crd->end) {
            if (!crd->block->next) return;
            crd->block = crd->block->next;
            crd->pos = crd->block->data;
            crd->end = crd->pos + chrome_block_len;
        }
        nlen = min(len, crd->end - crd->pos);
        if (dest) {
            memcpy(dest, crd->pos, nlen);
            dest += nlen;
        }
        crd->pos += nlen;
        len -= nlen;
    }
}

/* Replay chrome data into a raster pixmap.
   See runmap_play() for an explanation of arguments 
   base, sraster, cx, cy, cw, and ch. */
void
chrome_play(chrome_pos *cpos, 
            byte *base, int sraster, 
            int cx, int cy, int cw, int ch)
{
    chrome_reader crd;
    int cx2 = cx + cw;
    int cy2 = cy + ch;
    /* Opcode context */
    int x, sx, y, sy, w, h;
    byte c0[3], c1[3];
    byte *row;
    byte *c;
    int arg;
    /* Prepare chrome reader */
    crd.block = cpos->block;
    crd.pos = cpos->pos;
    crd.end = crd.block->data + chrome_block_len;
    /* Initialize opcode context */
    base = base - cy * sraster - cx * 3;
    c0[0] = c0[1] = c0[2] = 0;
    c1[0] = c1[1] = c1[2] = 0;
    x = sx = y = sy = 0;
    w = h = 1;
    row = 0;
    if (y>=cy && y<cy+ch) 
        row = base;
    /* Execute opcodes */
    for(;;) {
        byte op = chrome_getc(&crd);
        switch(op & 0xf0) {
            /* ---- Change X */
        case op_add_x:
            chrome_getarg(&crd, op, arg);
            x += arg;
            break;
        case op_sub_x:
            chrome_getarg(&crd, op, arg);
            x -= arg;
            sx = x;
            break;
        case op_add_x_short:
            x += 1 + (op & 0xf);
            break;
            /* ---- Change Y */
        case op_add_y:
            chrome_getarg(&crd, op, arg);
            y += arg;
            row = ((y>=cy && y <cy2) ? base + y * sraster : 0);
            break;
        case op_sub_y:
            chrome_getarg(&crd, op, arg);
            y -= arg;
            sy = y;
            row = ((y>=cy && y <cy2) ? base + y * sraster : 0);
            break;
        case op_add_y_short:
            y += 1 + (op & 0xf);
            row = ((y>=cy && y <cy2) ? base + y * sraster : 0);
            break;
            /* ---- Change W,H */
        case op_set_w:
            chrome_getarg(&crd, op, w);
            break;
        case op_set_w_short:
            w = 1 + (op & 0xf);
            break;
        case op_set_h:
            chrome_getarg(&crd, op, h);
            break;
        case op_set_h_short:
            h = 1 + (op & 0xf);
            break;
            /* ----- Runs */
        case op_run_c0:
            chrome_getarg(&crd, op, arg);
            c = c0;
            goto case_run;
        case op_run_c0_short:
            arg = 1 + (op & 0xf);
            c = c0;
            goto case_run;
        case op_run_c1:
            chrome_getarg(&crd, op, arg);
            c = c1;
            goto case_run;
        case op_run_c1_short:
            arg = 1 + (op & 0xf);
            c = c1;
        case_run:
            /* Draw run of length arg with color c */
            if (row) {
                byte *p1 = row + 3 * max(x,cx);
                byte *p2 = row + 3 * min(x+arg,cx2);
                while (p1 < p2) {
                    *p1++ = c[0];
                    *p1++ = c[1];
                    *p1++ = c[2];
                }
            }
            x += arg;
            break;
            /* ---- FillRect */
        case op_rect:
            arg = w * (1 + (op & 0xf));
            c0[0] = chrome_getc(&crd);
            c0[1] = chrome_getc(&crd);
            c0[2] = chrome_getc(&crd);
            /* Fill rectangle color c0 */
            if (y<cy2 && y+h>cy)
            {
                int y1 = max(y,cy);
                int y2 = min(y+h,cy2);
                int s1 = 3 * max(x,cx);
                int s2 = 3 * min(x+arg,cx2);
                byte *r = (row ? row : base + y1*sraster);
                while (y1 < y2) {
                    byte *p1 = r + s1;
                    byte *p2 = r + s2;
                    while (p1 < p2) {
                        *p1++ = c0[0];
                        *p1++ = c0[1];
                        *p1++ = c0[2];
                    }
                    y1 += 1;
                    r += sraster;
                }
            }
            x += arg;
            break;
        default:
            /* ---- Minor opcodes */
            switch(op) {
                /* ---- Pixmaps */
            case op_pixmap: 
                /* Fill pixmap with inline data */
                if (w>0) {
                    int ny = y;
                    int n1, n2, n3;
                    byte *r = 0;
                    while (ny < y+h && ny < cy) {
                        chrome_read(0, &crd, 3*w);
                        ny += 1;
                    }
                    n1 = (cx>x ? 3*(cx-x) : 0);
                    n3 = (x+w>cx2 ? 3*(x+w-cx2) : 0);
                    n2 = (3 * w) - n1 - n3;
                    r = base + ny * sraster + 3*max(x,cx);
                    while (ny < y+h && ny < cy2) {
                        chrome_read(0, &crd, n1);
                        chrome_read(r, &crd, n2);
                        chrome_read(0, &crd, n3);
                        r += sraster;
                        ny += 1;
                    }
                    while (ny < y+h) {
                        chrome_read(0, &crd, 3*w);
                        ny += 1;
                    }
                }
                sx = x;
                x += w;
                break;
                /* ---- Miscellaneous */
            case op_set_c0:
                c0[0] = chrome_getc(&crd);
                c0[1] = chrome_getc(&crd);
                c0[2] = chrome_getc(&crd);
                break;
            case op_set_c1:
                c1[0] = chrome_getc(&crd);
                c1[1] = chrome_getc(&crd);
                c1[2] = chrome_getc(&crd);
                break;
            case op_rest_x:
                x = sx;
                break;
            case op_rest_y:
                y = sy;
                row = ((y>=cy && y <cy2) ? base + y * sraster : 0);
                break;
            case op_end:
                return;
            default:
                ASSERT(0);
                break;
            }
            break;
        }
    }
}

/* Replay chrome data intersecting area cw*ch+cx+cy,
   (1) accumulating a colormap into ``colorhash'',
   (2) storing colordata pointers into a memory buffer ``base''.
   Aborts if the total number of colors exceeds ``maxcolors''. */
int
chrome_play_indexed(chrome_pos *cpos, 
                    htable *colorhash, int maxcolors,
                    colordata **base, int sraster, 
                    int cx, int cy, int cw, int ch)
{
    chrome_reader crd;
    int cx2 = cx + cw;
    int cy2 = cy + ch;
    /* Opcode context */
    int x, sx, y, sy, w, h;
    gx_color_index c0, c1;
    colordata *cd;
    colordata **row;
    byte rgb[3];
    int arg;
    /* Prepare chrome reader */
    crd.block = cpos->block;
    crd.pos = cpos->pos;
    crd.end = crd.block->data + chrome_block_len;
    /* Initialize opcode context */
    c0 = c1 = 0x000000;
    base = base - cy * sraster - cx;
    x = sx = y = sy = 0;
    w = h = 1;
    row = 0;
    if (y>=cy && y<cy+ch) 
        row = base;
    /* Execute opcodes */
    for(;;) {
        byte op = chrome_getc(&crd);
        switch(op & 0xf0) {
            /* ---- Change X */
        case op_add_x:
            chrome_getarg(&crd, op, arg);
            x += arg;
            break;
        case op_sub_x:
            chrome_getarg(&crd, op, arg);
            x -= arg;
            sx = x;
            break;
        case op_add_x_short:
            x += 1 + (op & 0xf);
            break;
            /* ---- Change Y */
        case op_add_y:
            chrome_getarg(&crd, op, arg);
            y += arg;
            row = ((y>=cy && y <cy2) ? base + y * sraster : 0);
            break;
        case op_sub_y:
            chrome_getarg(&crd, op, arg);
            y -= arg;
            sy = y;
            row = ((y>=cy && y <cy2) ? base + y * sraster : 0);
            break;
        case op_add_y_short:
            y += 1 + (op & 0xf);
            row = ((y>=cy && y <cy2) ? base + y * sraster : 0);
            break;
            /* ---- Change W,H */
        case op_set_w:
            chrome_getarg(&crd, op, w);
            break;
        case op_set_w_short:
            w = 1 + (op & 0xf);
            break;
        case op_set_h:
            chrome_getarg(&crd, op, h);
            break;
        case op_set_h_short:
            h = 1 + (op & 0xf);
            break;
            /* ----- Runs */
        case op_run_c0:
            chrome_getarg(&crd, op, arg);
            goto case_run0;
        case op_run_c0_short:
            arg = 1 + (op & 0xf);
        case_run0:
            if (row) {
                colordata **p1 = row + max(x,cx);
                colordata **p2 = row + min(x+arg,cx2);
                if (p2 > p1) {
                    if (! (cd = htable_lookup(colorhash, &c0, hash_rgb(c0), true)))
                        return_VMerror;
                    if (colorhash->nelems > maxcolors)
                        return 1;
                    while (p1 < p2)
                        *p1++ = cd;
                }
            }
            x += arg;
            break;
        case op_run_c1:
            chrome_getarg(&crd, op, arg);
            goto case_run1;
        case op_run_c1_short:
            arg = 1 + (op & 0xf);
        case_run1:
            if (row) {
                colordata **p1 = row + max(x,cx);
                colordata **p2 = row + min(x+arg,cx2);
                if (p2 > p1) {
                    if (! (cd = htable_lookup(colorhash, &c1, hash_rgb(c1), true)))
                        return_VMerror;
                    if (colorhash->nelems > maxcolors)
                        return 1;
                    while (p1 < p2)
                        *p1++ = cd;
                }
            }
            x += arg;
            break;
            /* ---- FillRect */
        case op_rect:
            arg = w * (1 + (op & 0xf));
            rgb[0] = chrome_getc(&crd);
            rgb[1] = chrome_getc(&crd);
            rgb[2] = chrome_getc(&crd);
            c0 = (rgb[0]<<16)|(rgb[1]<<8)|(rgb[2]);
            /* Fill rectangle */
            if (y<cy2 && y+h>cy)
            {
                int y1 = max(y,cy);
                int y2 = min(y+h,cy2);
                int s1 = max(x,cx);
                int s2 = min(x+arg,cx2);
                colordata **r = (row ? row : base + y1*sraster);
                if (! (cd = htable_lookup(colorhash, &c0, hash_rgb(c0), true)))
                    return_VMerror;
                if (colorhash->nelems > maxcolors)
                    return 1;
                while (y1 < y2) {
                    colordata **p1 = r + s1;
                    colordata **p2 = r + s2;
                    while (p1 < p2)
                        *p1++ = cd;
                    y1 += 1;
                    r += sraster;
                }
            }
            x += arg;
            break;
        default:
            /* ---- Minor opcodes */
            switch(op) {
                /* ---- Pixmaps */
            case op_pixmap:
                for (arg=y; arg<y+h; arg++) {
                    colordata **r = 0;
                    if (arg >= cy && arg < cy2)
                        r = base + arg * sraster;
                    for(sx=x; sx<x+w; sx++) {
                        gx_color_index c;
                        rgb[0] = chrome_getc(&crd);
                        rgb[1] = chrome_getc(&crd);
                        rgb[2] = chrome_getc(&crd);
                        c = (rgb[0]<<16)|(rgb[1]<<8)|(rgb[2]);
                        cd = htable_lookup(colorhash, &c, hash_rgb(c), true);
                        if (!cd) return_VMerror;
                        if (colorhash->nelems > maxcolors) 
                            return 1;
                        if (r && sx>=cx && sx<cx2)
                            r[sx] = cd;
                    }
                }
                sx = x;
                x += w;
                break;
                /* ---- Misc */
            case op_set_c0:
                rgb[0] = chrome_getc(&crd);
                rgb[1] = chrome_getc(&crd);
                rgb[2] = chrome_getc(&crd);
                c0 = (rgb[0]<<16)|(rgb[1]<<8)|(rgb[2]);
                break;
            case op_set_c1:
                rgb[0] = chrome_getc(&crd);
                rgb[1] = chrome_getc(&crd);
                rgb[2] = chrome_getc(&crd);
                c1 = (rgb[0]<<16)|(rgb[1]<<8)|(rgb[2]);
                break;
            case op_rest_x:
                x = sx;
                break;
            case op_rest_y:
                y = sy;
                row = ((y>=cy && y<cy2) ? base + y * sraster : 0);
                break;
            case op_end:
                return 0;
            default:
                ASSERT(0);
                break;
            }
            break;
        }
    }
}



/* ======================================
       C O L O R   R L E   F I L E S
   ====================================== */


/* Internal: Transparent color */
#define crle_transparent (0xfff)

/* Internal: Size of buffer for run output */
#define crle_buffer_size (512*4)

/* Internal: Data structure to keep track of run output */
typedef struct crle_output_s {
    FILE *f;
    int x, y;
    int w, h;
    byte *bufpos;
    byte  buffer[crle_buffer_size];
} crle_output;

/* Internal: Initialize crle_output data structure */
private int
crle_open(crle_output *crle, FILE *f, int w, int h, int ncolors, 
          gx_color_index *palette, const char *comment)
{
    int i;
    crle->f = f;
    crle->x = crle->y = 0;
    crle->w = w;
    crle->h = h;
    crle->bufpos = crle->buffer;
    fprintf(f, "R6\n");
    if (comment) fprintf(f, "# %s\n", comment);
    fprintf(f, "%d %d\n%d\n", w, h, ncolors);
    for(i=0; i<ncolors; i++) {
        byte rgb[3];
        rgb[0] = palette[i]>>16;
        rgb[1] = palette[i]>> 8;
        rgb[2] = palette[i];
        if (fwrite(rgb, 1, 3, f) != 3)
            return_error(gs_error_ioerror);            
    }
    return 0;
}

/* Internal: Outputs data buffered in crle_output data structure */
private int
crle_flush(crle_output *crle)
{
    int len = crle->bufpos - crle->buffer;
    if (len > 0) {
        if (fwrite(crle->buffer, 1, len, crle->f) != len)
            return_error(gs_error_ioerror);
        crle->bufpos = crle->buffer;
    }
    return 0;
}

/* Internal: Appends a run to crle output */
private inline int 
crle_write(crle_output *crle, int index, int len) 
{
    int code;
    int datum;
    /* Handle overflows */
    while (len > 0xfffff) {
        len -= 0xfffff;
        if ((code = crle_write(crle, index, 0xfffff)) < 0)
            return code;
    }
    /* Append run description */
    crle->x += len;
    datum = (index<<20) | len;
    *crle->bufpos++ = datum >> 24;
    *crle->bufpos++ = datum >> 16;
    *crle->bufpos++ = datum >> 8;
    *crle->bufpos++ = datum >> 0;
    if (crle->bufpos >= crle->buffer + crle_buffer_size - 4)
        if ((code = crle_flush(crle)) < 0)
            return code;
    /* Check line change */
    if (crle->x >= crle->w) {
        ASSERT(crle->x == crle->w);
        ASSERT(crle->y < crle->h); 
        crle->y += 1;
        crle->x = 0;
    }
    return 0;
}

/* Internal: Sorted list of foreground components */
typedef struct crle_comp_s {
    runmap *rmap;
    gx_color_index color;
    struct crle_comp_s *next;
} crle_comp;

/* Internal: Y-sorting subroutine for foreground components */
private int
crle_comp_sub(const void *pa, const void *pb)
{
    crle_comp *a = (crle_comp*)pa;
    crle_comp *b = (crle_comp*)pb;
    return a->rmap->ymin - b->rmap->ymin;
}

/* Internal: Description of a run */
typedef struct crle_run_s {
    uint c; /* palette color index */
    uint x; /* start of run */
    uint l; /* length of run */
} crle_run;

/* Internal: X-sorting subroutine for runs */
private int
crle_run_sub(const void *pa, const void *pb)
{
    crle_run *a = (crle_run*)pa;
    crle_run *b = (crle_run*)pb;
    return a->x - b->x;
}

int 
crle_save(p2mem *mem, 
          int width, int height,
          gx_color_index *palette, uint palettesize,
          int num, runmap **rmaps, gx_color_index *colors,
          const char *comment, 
          FILE *outfile)
{
    int i, x, y;
    int code;
    crle_output out;
    runmap *r;
    gx_color_index c;
    crle_comp *fgarray = 0;
    crle_comp *fglist;
    crle_comp **fgp;
    int maxruns = 0;
    int nruns = 0;
    crle_run *runs = 0;
    /* Allocate and fill fgarray */
    fgarray = p2mem_alloc(mem, sizeof(crle_comp) * num);
    if (num && !fgarray) return_VMerror;
    for (i=0; i<num; i++) {
        fgarray[i].rmap = rmaps[i];
        fgarray[i].color = colors[i];
    }
    /* Sort and link fgarray */
    if (num > 1)
        qsort(fgarray, num, sizeof(crle_comp), crle_comp_sub);
    fglist = fgarray;
    for (i=1; i<num; i++)
        fgarray[i-1].next = &fgarray[i];
    if (num>0)
        fgarray[num-1].next = 0;
    /* Prepare output */
    code = crle_open(&out, outfile, width, height, 
                     palettesize, palette, comment);
    if (code < 0) goto exit;
    /* Iterate on rows */
    for (y=0; y<height; y++) {
        nruns = 0;
        fgp = &fglist;
        while ( (*fgp) && (*fgp)->rmap->ymin <= y) {
            c = (*fgp)->color;
            r = (*fgp)->rmap;
            if (r->ymax < y) {
                /* This drawlist has been completely processed */
                (*fgp) = (*fgp)->next;
            } else {
                /* This drawlist intersects the current row */
                byte *data = r->data + r->rows[y - r->ymin];
                byte *dataend = r->data + r->rows[y - r->ymin + 1];
                int reqruns = nruns + (dataend - data);
                if (reqruns > maxruns) {
                    int newmaxruns = max(reqruns, maxruns+maxruns);
                    runs = p2mem_resize(mem, runs, 
                                        sizeof(crle_run)*newmaxruns);
                    if (!runs) goto exitmem;
                }
                x = 0;
                while (data < dataend) {
                    rl_decode(data, x);
                    runs[nruns].x = x;
                    if (data < dataend) {
                        rl_decode(data, x);
                        runs[nruns].l = x - runs[nruns].x;
                        runs[nruns].c = c;
                        nruns += 1;
                    }
                }
                fgp = &(*fgp)->next;
            }
        }
        /* Sort all runs on the row */
        if (nruns > 1)
            qsort(runs, nruns, sizeof(crle_run), crle_run_sub);
        /* Output row */
        x = 0;
        for (i=0; i<nruns; i++) {
            ASSERT(runs[i].x >= x);
            if (runs[i].x > x) {
                crle_write(&out, crle_transparent, runs[i].x - x);
                x = runs[i].x;
            }
            if (runs[i].l > 0) {
                crle_write(&out, runs[i].c, runs[i].l);
                x += runs[i].l;
            }
        }
        ASSERT(x <= width);
        if (x < width)
            crle_write(&out, crle_transparent, width - x);
    }
    /* Success */
    code = crle_flush(&out);
    goto exit;
 exitmem:
    /* Memory error */
    code = gs_note_error(gs_error_VMerror);
 exit:
    /* Cleanup and terminate */
    p2mem_free(mem, runs);
    p2mem_free(mem, fgarray);
    return code;
}
