/* -*- Mode: c; c-file-style: "bsd"; -*- 
   $Id: gdevdjvu.c,v 2.6 2001/04/17 01:16:04 leonb Exp $

   -------------------------------------------------------------------------- 
   DjVu Device for Ghostscript 
   -- Leon Bottou, June-October 2000
   -- Copyright (C) 2000 AT&T.

   ------------------------------------------------------------------------ 

   This driver implements two devices:
   * Device "djvumask" outputs the foreground mask as PBM files.
   * Device "djvusep" outputs separation files containing one or several
     pages. Each page contains the foreground encoded as a CRLE image
     (cf. comments on Color RLE image below), possibly followed by a
     subsampled PPM image representing the background, possibly followed by an
     arbitrary number of comment lines starting with character '#'.
     These files should be piped through the back-end encoder "csepdjvu".
   
   The following command line parameters are supported:
   * "-sOutputFile=<string>"  Selects the name of the output file.
                              The usual Ghostscript conventions apply.
   * "-dThreshold=<0..100>"   Selects the separation threshold.  Larger
                              values put more things into the foreground
                              layer.  Default value is 80
   * "-dBgSubsample=<1-12>"   Selects the background subsampling factor.
                              Default value is 3.
   * "-dFgColors=<1-4000>"    Selects the maximal number of colors in the
                              foreground layer. Default value is 256.
   * "-dFgImgColors=<0-4000>" Images with less than the specified number of
                              colors might be moved into the foreground.  
                              Default value is 256.
   * "-dMaxBitmap=<num>"      Specifies the maximal amount of memory used
                              by the banding code when rendering the background
                              layer.  Default is 10000000.
   * "-dAutoHires"            This option enables an algorithm that lets
                              device "djvusep" ignore -dBgSubsample and 
			      generate a full resolution background layer
			      when the foreground is empty.
   * "-dReopenPerPage"        Specifies that the output file must be reopened
                              for each page.  Default is to reopen if the 
			      filename contains a "%d" specification for 
			      the page number.

   ------------------------------------------------------------------------ */   
   
#include "stdpre.h"
#include "arch.h"
#include "ctype_.h"
#include "memory_.h"
#include "string_.h"
#include <stdlib.h>
#include "gserrors.h"
#include "gsmemory.h"
#include "gsdevice.h"
#include "gstypes.h"
#include "gsrect.h"
#include "gscdefs.h"
#include "gsstruct.h"
#include "gsparam.h"
#include "gx.h"
#include "gxstdio.h"
#include "gxdevice.h"
#include "gxdevmem.h"
#include "gxbitmap.h"
#include "gxgetbit.h"
#include "gximage.h"
#include "gxlum.h"
#include "gxalloc.h"
#include "gdevprn.h"

#include "gdevdjv1.h"


/* Debugging characters for gs option -z */
#define DEBUG_CHAR_DLIST    0
#define DEBUG_CHAR_COLOR    0
#define DEBUG_CHAR_P2MEM    0
#define DEBUG_CHAR_CHROME   0
#define DEBUG_CHAR_LOCOLOR  0
#define DEBUG_CHAR_BG       0



/* ======================================
       D R A W I N G     L I S T
   ====================================== */

/* The first job of the maskpbm device is to build a list of drawlist records
   representing all drawing operations.  Each drawlist record essentially
   contains a flag word (see below), a mask runmap describing its extent, 
   and a color index representing the single color of the drawing element
   (or gx_no_color_index when the drawing element contains several colors). */

/* Drawlist head */
typedef struct drawlist_head_s {
    struct drawlist_s *first;
    struct drawlist_s *last;
} drawlist_head;

/* Drawlist element */
typedef struct drawlist_s {
    struct drawlist_s *next;   /* linked list pointer */
    struct drawlist_s *prev;   /* linked list pointer */
    runmap *mask;              /* shape of the object */
    uint flags;                /* type for the object (see below) */
    gx_color_index color;      /* pure color or gx_no_color_index */
    chrome_pos *chromepos;     /* non zero when color is gx_no_color_index */
    struct drawlist_s *bglink; /* cf. section drawlist classification */
    int perimeter;             /* cf. section drawlist classification */
    int area;                  /* cf. section drawlist classufication */
    int palcolor;              /* cf. section foreground colors */
} drawlist;

/* Drawlist flags. */
#define DLIST_FOREGROUND     (0x1)     /* Assigned to foreground */
#define DLIST_BACKGROUND     (0x2)     /* Assigned to background */
#define DLIST_INPURE         (0x10)    /* Has more than one color */
#define DLIST_TEXT           (0x20)    /* Drawing arises from text operators */
#define DLIST_PATH           (0x40)    /* Drawing arises from path operators */
#define DLIST_PATH_FILL      (0x80)    /* Drawing arises from path fill operator */
#define DLIST_HASGRAY        (0x1000)  /* Color(s) may include non b&w colors */
#define DLIST_HASCOLOR       (0x2000)  /* Color(s) may include non gray colors */
#define DLIST_RECURSIVE      (0x10000) /* Already processing high level routine */

/* Return flags indicating whether color represents
   black or white , gray shades, or actual colors. */
#define color_flags(color) \
  ((color^(color>>8))&0xffff) ? (DLIST_HASCOLOR|DLIST_HASGRAY) \
    : (color && color!=0xffffff) ? (DLIST_HASGRAY) : 0 

/* Appends a new drawlist element. */
private drawlist *
drawlist_append(p2mem *mem, drawlist_head *head)
{
    drawlist *d = p2mem_alloc(mem, sizeof(drawlist));
    if (!d) return 0;
    memset(d, 0, sizeof(drawlist));
    d->color = gx_no_color_index;
    d->next = 0;
    d->prev = head->last;
    head->last = d;
    (d->prev) ? (d->prev->next = d) : (head->first = d);
    return d;
}

/* Inserts a new drawlist element before a given element. */
private drawlist *
drawlist_insert(p2mem *mem, drawlist_head *head, drawlist *pos)
{
    drawlist *d = p2mem_alloc(mem, sizeof(drawlist));
    if (!d) return 0;
    memset(d, 0, sizeof(drawlist));
    d->color = gx_no_color_index;
    d->next = pos;
    d->prev = (pos ? pos->prev : head->last);
    (d->next) ? (d->next->prev = d) : (head->last  = d);
    (d->prev) ? (d->prev->next = d) : (head->first = d);
    return d;
}

/* Destroy a drawlist element. */
private void
drawlist_remove(p2mem *mem, drawlist_head *head, drawlist *d)
{
    (d->next) ? (d->next->prev = d->prev) : (head->last = d->prev);
    (d->prev) ? (d->prev->next = d->next) : (head->first = d->next);
    if (mem) {
        if (d->mask) 
            runmap_free(d->mask);
        p2mem_free(mem, d);
    }
}

/* Compact display for debugging purposes. */
#ifdef DEBUG
private void
drawlist_print(drawlist *dl)
{
    fprintf(stderr,"  --");
    if (dl->flags & DLIST_FOREGROUND)
	fprintf(stderr," fg");
    else if (dl->flags & DLIST_BACKGROUND)
	fprintf(stderr," bg");
    if (dl->mask)
        fprintf(stderr," %dx%d+%d+%d", 
                dl->mask->xmax - dl->mask->xmin +1, 
                dl->mask->ymax - dl->mask->ymin +1, 
                dl->mask->xmin, 
                dl->mask->ymin );
    if (dl->color != gx_no_color_index)
        fprintf(stderr," purecolor=%06x", (uint)(dl->color));
    if (dl->flags & DLIST_HASCOLOR)
        fprintf(stderr," hascolor");
    else if (dl->flags & DLIST_HASGRAY)
        fprintf(stderr," hasgray");
    if (dl->flags & DLIST_INPURE)
        fprintf(stderr," inpure");
    if (dl->flags & DLIST_PATH)
        fprintf(stderr," path");
    if (dl->flags & DLIST_PATH_FILL)
        fprintf(stderr," fill");
    if (dl->flags & DLIST_TEXT)
        fprintf(stderr," text");
    if (dl->perimeter)
	fprintf(stderr," peri=%d", dl->perimeter);
    if (dl->area)
	fprintf(stderr," area=%d", dl->area);
    if (dl->palcolor)
	fprintf(stderr," palcolor=%d", dl->palcolor);
    if (dl->chromepos)
	fprintf(stderr," haschrome");
    fprintf(stderr,"\n");
}
#endif

/* Render drawlist entries that have specific flags set.
   See runmap_play() for an explanation of arguments 
   base, sraster, cx, cy, cw, and ch. */
private void
drawlist_play(drawlist_head *head, uint flags,
              byte *base, int sraster, int cx, int cy, int cw, int ch)
{
    /* Make up for negative coordinates in rectangle */
    if (cx < 0) {
        cw += cx;
        base -= cx;
        cx -= cx;
    }
    if (cy < 0) {
        ch += cy;
        base -= cy * sraster;
        cy -= cy;
    }
    /* Render */
    if (cw > 0 && ch > 0) {
        drawlist *dl;
        for (dl = head->first; dl; dl = dl->next) {
            if (!(dl->mask) || 
                !(dl->flags & flags) ||
                dl->mask->ymax < (uint)(cy) ||
                dl->mask->xmax < (uint)(cx) || 
                dl->mask->ymin >= (uint)(cy + ch) ||
                dl->mask->xmin >= (uint)(cx + cw)  )
                continue;
            /* Render drawlist element */
            if (dl->color != gx_no_color_index) {
                runmap_play(dl->mask, dl->color, base, sraster, cx, cy, cw, ch);
            } else {
                ASSERT(dl->chromepos);
                chrome_play(dl->chromepos, base, sraster, cx, cy, cw, ch);
            }
        }
    }
}




/* ======================================
       P D F M A R K S 
   ====================================== */

/* The pdfmark structure (links only for now) */
typedef struct pdfmark_s pdfmark;
struct pdfmark_s {
    pdfmark *next;
    char *uri;
    char *geometry;
};

/* Free a link structure */
private void
pdfmark_free(p2mem *mem, pdfmark *mark)
{
    if (mark) {
        p2mem_free(mem, mark->uri);
        p2mem_free(mem, mark->geometry);
        p2mem_free(mem, mark);
    }
}

/* Internal */
private int
pdfmark_eq(const gs_param_string *p, const char *q)
{
    return ( p->size == strlen(q) && !memcmp(p->data, q, p->size) );
}

/* Internal */
private int
pdfmark_dup(p2mem *mem, const gs_param_string *p, char **out)
{
    if (! (*out = p2mem_alloc(mem, p->size+1))) return_VMerror;
    memcpy(*out, p->data, p->size);
    (*out)[p->size] = 0;
    return 0;
}

/* Internal */
private int
pdfmark_find(p2mem *mem, gs_param_string_array *pma, 
             const char *key, char **out)
{
    int i;
    for (i=0; i<pma->size-2; i+=2)
        if (pdfmark_eq(&pma->data[i], key)) 
            return pdfmark_dup(mem, &pma->data[i+1], out);
    *out = 0;
    return 1;
}

/* Prepare a pdfmark structure */
private int
pdfmark_create(p2mem *mem, gs_param_string_array *pma, pdfmark **pmark)
{
    pdfmark *mark = 0;
    char *temp0 = 0;
    char *temp1 = 0;
    char *temp2 = 0;
    gs_matrix ctm;
    gs_rect rect;
    double v[4];
    int code = 0;
    char c;
    /* Only handle LNK annotations (for now) */
    *pmark = 0;
    if (pma->size < 1 ||
        pma->data[pma->size-1].size != 3 ||
        memcmp(pma->data[pma->size-1].data, "LNK", 3) )
        return 1;
    /* Allocate link object */
    if (! (mark = p2mem_alloc(mem, sizeof(pdfmark))))  goto exitmem;
    memset(mark, 0, sizeof(pdfmark));
    /* Compute uri */
    if (((code = pdfmark_find(mem, pma, "/A", &temp0)) < 0) ||
        ((code = pdfmark_find(mem, pma, "/URI", &temp1)) < 0) ||
        ((code = pdfmark_find(mem, pma, "/Page", &temp2)) < 0 ) )
        goto exit;
    if (temp0) {  /* Action: "<< ... /URI (...) >>" */
        int state = 0;
        const char *c, *s;
        for (c=s=temp0; *s; s++) {
            if (state<4 && *s == ("/URI")[state]) {
                state += 1;
            } else if (state==4 && *s=='(') {
                c = s;
                state = 5;
            } else if (state==4 && strchr(" \n\r\t", *s)) {
                state = 4;
            } else if (state==5 && *s=='\\') {
                state = 6;
            } else if (state==5 && *s==')') {
                mark->uri = p2mem_alloc(mem, s-c+2);
                memcpy(mark->uri, c, s-c+1);
                mark->uri[s-c+1] = 0;
                break;
            } else if (state>=5) {
                state = 5;
            } else {
                state = ((*s == '/') ? 1 : 0);
            }
        }
    } else if (temp1) { /* Format: "(...)" */
        mark->uri = temp1;
        temp1 = 0;
    } else if (temp2) { /* Format: "123" */
        mark->uri = p2mem_alloc(mem, strlen(temp2) + 4);
        if (! mark->uri) goto exitmem;
        strcpy(mark->uri, "(#");
        strcat(mark->uri, temp2);
        strcat(mark->uri, ")");
    } 
    /* Cleanup */
    p2mem_free(mem, temp0);
    p2mem_free(mem, temp1);
    p2mem_free(mem, temp2);
    temp0 = temp1 = temp2 = 0;
    if (!mark->uri) {
        code = 1;
        goto exit;
    }
    /* Compute geometry */
    if (((code = pdfmark_dup(mem, &pma->data[pma->size-2], &temp1)) < 0) ||
        ((code = pdfmark_find(mem, pma, "/Rect", &temp2)) < 0) )
        return code;
    code = gs_error_rangecheck;
    if (!temp1 || !temp2)
        goto exit;
    if (sscanf(temp1, "[ %g %g %g %g %g %g %c",
               &ctm.xx, &ctm.xy, &ctm.yx, &ctm.yy, &ctm.tx, &ctm.ty, &c) != 7)
        goto exit;
    if (sscanf(temp2, "[ %lg %lg %lg %lg %c",
	       &v[0], &v[1], &v[2], &v[3], &c) != 5 )
        goto exit;
    gs_point_transform(v[0], v[1], &ctm, &rect.p);
    gs_point_transform(v[2], v[3], &ctm, &rect.q);
    mark->geometry = p2mem_alloc(mem, 30);
    if (! mark->geometry) goto exitmem;
    sprintf(mark->geometry, "%dx%d+%d+%d",
            abs((int)(rect.p.x - rect.q.x)), 
            abs((int)(rect.p.y - rect.q.y)),
            min((int)rect.p.x, (int)rect.q.x),
            min((int)rect.p.y, (int)rect.q.y) );
    p2mem_free(mem, temp1);
    p2mem_free(mem, temp2);
    temp1 = temp2 = 0;
    /* PDF defines numerous other fields definining borders and hiliting.  Few
       can be used because Ghostscript only passes /View and /Border, and
       because DjVu borders and hiliting modes are different. */
    /* Success */
    *pmark = mark;
    mark = 0;
    return 0;
 exitmem:
    code = gs_error_VMerror;
 exit:
    p2mem_free(mem, temp0);
    p2mem_free(mem, temp1);
    p2mem_free(mem, temp2);
    pdfmark_free(mem, mark);
    if (code < 0) return gs_note_error(gs_error_VMerror);
    return code;
}



/* ======================================
       D J V U    D E V I C E
   ====================================== */

/* Forward declarations */
typedef struct gx_device_djvu_s gx_device_djvu;

/* Declaring the process procedure. */
#define djvu_proc_process(process) int process(gx_device_djvu *dev)

/* The device structure. */
struct gx_device_djvu_s {
    gx_device_common;
    /* Procedure vector */
    djvu_proc_process((*process));
    /* Parameters */
    int    threshold;
    int    fgcolors;
    int    fgimgcolors;
    int    bgsubsample;
    long   maxbitmap;
    char   outputfilename[prn_fname_sizeof];
    bool   reopenperpage;
    bool   autohires;
    bool   extracttext;
    bool   quiet;
    /* Device data */
    p2mem          *pmem;          /* stable memory */
    FILE           *outputfile;    /* output filename */
    drawlist_head   head;          /* drawlist */
    chrome         *gchrome;       /* chrome data */
    gx_color_index *fgpalette;     /* fgcolors */
    uint            fgpalettesize; /* number of fgcolors */
    pdfmark        *marks;         /* hyperlinks etc. */
    /* Current drawlist component */
    runmapbld      *curmask;       /* accumulated mask */
    gx_color_index  curcolor;      /* color or gx_no_color_index */
    uint            curflags;      /* flags */
    chrome_pos     *curchrome;     /* optional chrome position */
    bool            curbreak;      /* see comment in begin_typed_image */
};

gs_private_st_suffix_add0_final(st_device_djvu,gx_device_djvu,"gx_device_djvu", 
                                device_djvu_enum_ptrs, device_djvu_reloc_ptrs,
                                gx_device_finalize, st_device );

/* Device procedures. */
private dev_proc_open_device(djvu_open);
private dev_proc_output_page(djvu_output_page);
private dev_proc_close_device(djvu_close);
private dev_proc_get_params(djvu_get_params);
private dev_proc_put_params(djvu_put_params);
private dev_proc_fill_rectangle(djvu_fill_rectangle);
private dev_proc_copy_mono(djvu_copy_mono);
private dev_proc_copy_color(djvu_copy_color);
private dev_proc_stroke_path(djvu_stroke_path);
private dev_proc_fill_path(djvu_fill_path);
private dev_proc_begin_typed_image(djvu_begin_typed_image);
private dev_proc_text_begin(djvu_text_begin);

/* Device procs */
#define djvu_device_procs { \
    djvu_open, 0, 0, djvu_output_page, djvu_close, \
    gx_default_rgb_map_rgb_color, gx_default_rgb_map_color_rgb, \
    djvu_fill_rectangle, 0, djvu_copy_mono, djvu_copy_color, \
    0, 0, djvu_get_params, djvu_put_params, 0, 0, 0, 0, \
    gx_page_device_get_page_device, 0, 0, 0, 0, \
    djvu_fill_path, djvu_stroke_path, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, \
    djvu_begin_typed_image, 0, 0, 0, 0, djvu_text_begin }

/* Setting up a mask device */
#define djvu_device_body(name,proc) \
   std_device_color_stype_body(gx_device_djvu, 0, name, &st_device_djvu, \
                               (int)((long)DEFAULT_WIDTH_10THS*300/10),  \
	   		       (int)((long)DEFAULT_HEIGHT_10THS*300/10), \
				300, 300, 24, 255, 256 ), \
   djvu_device_procs, proc, 80, 256, 256, 3, 10000000 

/* Open the device. */
private int
djvu_open(gx_device * dev)
{
    gx_device_djvu *cdev = (gx_device_djvu *)dev;
    cdev->head.first = 0;
    cdev->head.last = 0;
    cdev->gchrome = 0;
    cdev->curmask = 0;
    cdev->curflags = 0;
    cdev->curcolor = 0;
    cdev->curchrome = 0;
    cdev->curbreak = false;
    cdev->marks = 0;
    cdev->pmem = p2mem_create();
    if (!cdev->pmem)
        return_VMerror;
    return 0;
}

/* Flush current runmapbld into drawlist. */
private int
djvu_flush_current(gx_device_djvu *cdev)
{
    int code = 0;
    /* Proceed */
    if (cdev->curmask) {
        runmap *mask;
        drawlist *last;
        if ((code = runmapbld_close(cdev->curmask, &mask)) < 0)
            return code;
        /* Terminate chrome data if present */
        if (cdev->curchrome) 
            chrome_closepos(cdev->gchrome, cdev->curchrome);
        /* Attempt to merge path operations */
        last = cdev->head.last;
        if (mask && last && !cdev->curchrome 
            && cdev->curcolor == last->color 
            && ((cdev->curflags ^ last->flags) & ~DLIST_PATH_FILL) == 0
            && runmap_hittest(mask, last->mask) ) {
            /* Merge with previous */
            last->flags |= cdev->curflags;
            code = runmap_or(cdev->pmem, mask, last->mask, 3, &last->mask);
        } else if (mask) {
            /* Create new element */
            drawlist *dl = drawlist_append(cdev->pmem, &cdev->head);
            if (! dl) return_VMerror;
            dl->flags = cdev->curflags;
            dl->color = cdev->curcolor;
            dl->chromepos = cdev->curchrome;
            dl->mask = mask;
#ifdef DEBUG
            if (cdev->curchrome && gs_debug_c(DEBUG_CHAR_CHROME))
                drawlist_print(dl);
#endif
        }
    }
    cdev->curflags = 0;
    cdev->curmask = 0;
    cdev->curcolor = 0;
    cdev->curchrome = 0;
    cdev->curbreak = false;
    return code;
}

/* Flushes only if curbreak is set and if 
   the current object bounding box does 
   not touch the specified rectangle WxH+X+Y. */
private int
djvu_flush_maybe(gx_device_djvu *cdev, int x, int y, int w, int h)
{
    int code;
    runmap *r;
    if (cdev->curbreak) {
        cdev->curbreak = false;
        if (cdev->curmask) {
            if ((code = runmapbld_flush(cdev->curmask)) < 0)
                return code;
            if ((r = cdev->curmask->rmap))
                if (x>r->xmax+1 || y>r->ymax+1 || x+w<r->xmin || y+h<r->ymin)
                    return djvu_flush_current(cdev);
        }
    }
    return 0;
}

/* Internal: Setup chrome data for this object */
private int
djvu_check_chrome(gx_device_djvu *cdev, gx_color_index color)
{
    int code;
    if (! cdev->curchrome) {
        /* Mark object has having inpure color */
        cdev->curflags |= DLIST_INPURE;
        /* Create chrome data if needed */
        if (!cdev->gchrome && !(cdev->gchrome = chrome_create()))
            return_VMerror;
        if (! (cdev->curchrome = chrome_getpos(cdev->gchrome)))
            return_VMerror;
        /* Store existing runmap into chrome */
        if (cdev->curmask) {
            runmapbld_flush(cdev->curmask);
            code = chrome_put_runmap(cdev->gchrome, 
                                     cdev->curmask->rmap, cdev->curcolor);
            if (code < 0) return code;
        }
    }
    return 0;
}

/* Make sure that there is a current runmapbld. */
private int
djvu_check_current(gx_device_djvu *cdev, gx_color_index color)
{
    int code = 0;
    cdev->curbreak = false;
    if (! cdev->curmask) {
        /* Start a new object */
        if (color == gx_no_color_index)
            if ((code = djvu_check_chrome(cdev, color)) < 0)
                return code;
        code = runmapbld_open(cdev->pmem, runmapbld_buffer_size, &cdev->curmask);
        cdev->curcolor = color;
        cdev->curflags = 0;
    } else if (color != cdev->curcolor) {
        /* Color is no longer a single color */
        code = djvu_check_chrome(cdev, color);
        cdev->curcolor = gx_no_color_index;
    }
    return code;
}

/* Clean up page data. */
private void
djvu_close_page(gx_device_djvu *cdev)
{
    p2mem_freeall(cdev->pmem);
    chrome_destroy(cdev->gchrome);
    cdev->curmask = 0;
    cdev->head.first = 0;
    cdev->head.last = 0;
    cdev->gchrome = 0;
    cdev->fgpalette = 0;
    cdev->fgpalettesize = 0;
    cdev->marks = 0;
}

/* GS callback: Output a page. */
private int
djvu_output_page(gx_device * dev, int num_copies, int flush)
{
    int code = 0;
    gx_device_djvu *cdev = (gx_device_djvu *)dev;
    code = djvu_flush_current(cdev);
    if (code < 0) return code;
    /* open output file if not already open */
    if (!cdev->outputfile && cdev->outputfilename[0])
        code = gx_device_open_output_file(dev, cdev->outputfilename, 
                                          true, false, &cdev->outputfile);
    /* process */
    if (code < 0) return code;
    if (!cdev->process) return_error(gs_error_unregistered);
    code = (*cdev->process)(cdev);
    if (code < 0) return code;
    /* cleanup and return */
    if (flush)
        djvu_close_page(cdev);
    if (cdev->reopenperpage) {
        if (cdev->outputfile)
            gx_device_close_output_file(dev, cdev->outputfilename, 
                                        cdev->outputfile);
        cdev->outputfile = 0;
    }
    return gx_finish_output_page(dev, num_copies, flush);
}

/* GS callback: Close the device. */
private int
djvu_close(gx_device * dev)
{
    gx_device_djvu *cdev = (gx_device_djvu *) dev;
    djvu_close_page(cdev);
    if (cdev->outputfile)
        gx_device_close_output_file(dev, cdev->outputfilename, 
                                    cdev->outputfile);
    cdev->outputfile = 0;
    p2mem_destroy(cdev->pmem);
    cdev->pmem = 0;
    return 0;
}

/* GS callback: Get parameters. */
private int
djvu_get_params(gx_device * dev, gs_param_list * plist)
{
    int code;
    gx_device_djvu *cdev = (gx_device_djvu *) dev;
    gs_param_string ofns;
    ofns.data = (const byte *)cdev->outputfilename;
    ofns.size = strlen(cdev->outputfilename);
    ofns.persistent = false;
    code = gx_default_get_params(dev, plist);
#define GET(param_write,param_name, place) \
    if (code >= 0) code=param_write(plist, param_name, place)
    GET(param_write_string, "OutputFile", &ofns);
    GET(param_write_int, "Threshold", &cdev->threshold);
    GET(param_write_int, "FgColors", &cdev->fgcolors);
    GET(param_write_int, "FgImgColors", &cdev->fgimgcolors);
    GET(param_write_int, "BgSubsample", &cdev->bgsubsample);
    GET(param_write_long, "MaxBitmap", &cdev->maxbitmap);
    GET(param_write_bool, "ReopenPerPage", &cdev->reopenperpage);
    GET(param_write_bool, "AutoHires", &cdev->autohires);
    GET(param_write_bool, "ExtractText", &cdev->extracttext);
    GET(param_write_bool, "QUIET", &cdev->quiet);
    if (code >= 0) code=param_write_null(plist, "pdfmark");
#undef GET
    return code;
}

/* Internal: Process pdfmarks */
private int
djvu_pdfmark(gx_device_djvu *cdev, gs_param_string_array *pma)
{
    pdfmark *mark = 0;
    int code = pdfmark_create(cdev->pmem, pma, &mark);
    if (code >= 0 && mark) {
        mark->next = cdev->marks;
        cdev->marks = mark;
    }
    return code;
}

/* Internal: Validate outputfilename */
private bool
validate_outputfilename(const char *data, int size, bool *rpp)
{
    const char *hasformat = 0;
    gs_parsed_file_name_t parsed;
    int code = gx_parse_output_file_name(&parsed, &hasformat, data, size);
    if (code<0 || size>=prn_fname_sizeof)
        return false;
    *rpp = (hasformat ? true: false);
    return true;
}

/* GS callback: Put parameters. */
private int
djvu_put_params(gx_device * dev, gs_param_list * plist)
{
    gx_device_djvu *cdev = (gx_device_djvu *) dev;
    bool was_open = dev->is_open;
    int ncode = 0;
    int code = 0;
    /* Parameters and defaults */
    gs_param_string ofs;
    int thr = cdev->threshold;
    int fgc = cdev->fgcolors;
    int fgi = cdev->fgimgcolors;
    int bgs = cdev->bgsubsample;
    long mbm = cdev->maxbitmap;
    bool rpp = cdev->reopenperpage;
    bool ahi = cdev->autohires;
    bool txt = cdev->extracttext;
    bool quiet = cdev->quiet;
    /* Handle pseudo-parameter pdfmark */
    gs_param_string_array pma;
    if (param_read_string_array(plist, "pdfmark", &pma) == 0)
        return djvu_pdfmark(cdev, &pma);
    /* Validation macro for other parms */
#define PUT(param_read, param_name, place, predicate) \
    ncode = param_read(plist, param_name, place); \
    if (ncode == 0 && !(predicate)) { \
        ncode = gs_error_limitcheck; } \
    if (ncode < 0) { code=ncode; \
        param_signal_error(plist, param_name, code); } 
    /* Validate OutputFile */
    ofs.data = 0;
    PUT(param_read_string, "OutputFile", &ofs, 
        validate_outputfilename((const char*)ofs.data, ofs.size, &rpp));
    /* Validate remaining parms */
    PUT(param_read_int, "Threshold", &thr, (thr>=0 && thr<=100));
    PUT(param_read_int, "FgColors", &fgc, (fgc>=1 && fgc<=4000));
    PUT(param_read_int, "FgImgColors", &fgi, (fgi>=0 && fgi<=4000));
    PUT(param_read_int, "BgSubsample", &bgs, (bgs>=1 && bgs<=12));
    PUT(param_read_long, "MaxBitmap", &mbm, (mbm<=1000000000));
    PUT(param_read_bool, "ReopenPerPage", &rpp, true);
    PUT(param_read_bool, "AutoHires", &ahi, true);
    PUT(param_read_bool, "ExtractText", &txt, true);
    PUT(param_read_bool, "QUIET", &quiet, true);
#undef PUT
    /* Terminate validation */
    if (code >= 0) {
	cdev->is_open = false;
	code = gx_default_put_params(dev, plist);
	cdev->is_open = was_open;
    }
    if (code < 0)
        return code;
    /* Install parameters */
    cdev->threshold = thr;
    cdev->fgcolors = fgc;
    cdev->fgimgcolors = fgi;
    cdev->bgsubsample = bgs;
    cdev->maxbitmap = max(1000000, mbm);
    cdev->reopenperpage = rpp;
    cdev->autohires = ahi;
    cdev->extracttext = txt;
    cdev->quiet = quiet;
    /* Install ``OutputFile'' */
    if (ofs.data) {
        if (ofs.size != strlen(cdev->outputfilename) ||
            memcmp(ofs.data, cdev->outputfilename, ofs.size) ) {
            /* Modify outputfilename */
            if (was_open)  
                discard(gs_closedevice(dev));
            memcpy(cdev->outputfilename, ofs.data, ofs.size);
            cdev->outputfilename[ofs.size] = 0;
            if (was_open)  
                code = gs_opendevice(dev);
        }
    }
    return code;
}

/* ------ low-level rendering procs ------ */

/* GS callback: fill a rectangle with solid color */
private int
djvu_fill_rectangle(gx_device *dev, int x, int y, int w, int h,
		    gx_color_index color)
{
    int code;
    gx_device_djvu * const cdev = (gx_device_djvu *)dev;
    /* Ignore initial white fills */
    if (!cdev->head.last && !cdev->curmask)
        if (color == gx_device_white(dev))
            return 0;
    /* Check for break */
    fit_fill(dev, x, y, w, h);
    if (cdev->curbreak) {
        code = djvu_flush_maybe(cdev, x, y, w, h);
        if (code < 0) return code;
    }
    /* Accumulate into current mask */
    cdev->curflags |= color_flags(color);
    if ((code = djvu_check_current(cdev, color)) < 0)
        return code;
    if ((code = runmapbld_put_rect(cdev->curmask, x, y, w, h)) < 0)
        return code;
    /* Save chrome info */
    if (cdev->curchrome)
        if ((code = chrome_put_rect(cdev->gchrome, x, y, w, h, color)) < 0)
            return code;
    return 0;
}

/* GS callback: copy bitmap with specified fg/bg colors */
private int
djvu_copy_mono(gx_device *dev,
	       const byte * base, int sourcex, int sraster, gx_bitmap_id id,
	       int x, int y, int w, int h, 
	       gx_color_index color0, gx_color_index color1)
{
    int code;
    gx_device_djvu * const cdev = (gx_device_djvu *)dev;
    /* Check for break */
    fit_copy(dev, base, sourcex, sraster, id, x, y, w, h);
    if (cdev->curbreak) {
        code = djvu_flush_maybe(cdev, x, y, w, h);
        if (code < 0) return code;
    }
    /* Attempt to do something smart about scanned bilevel images */
    if (!cdev->head.last) {
        /* We test that (a) this is the first page component, (b) this
           component has been drawn with pure black color, and (c) this image
           is drawn below all other drawings (banding). */
        bool maybescan = true;
        if (cdev->curcolor != 0x000000)
            maybescan = false;
        if (cdev->curmask) {
            runmapbld *bld = cdev->curmask;
            if (bld->rmap && y<=bld->rmap->ymax)
                maybescan = false;
            else if (bld->nruns>0 && y<=bld->runs[bld->nruns-1][0])
                maybescan = false;
        }                
        if (maybescan) {
            /* Convert b&w image to imagemask */
            if (color0 == 0xffffff && color1 == 0x000000)
                color0 = gx_no_color_index;
            if (color1 == 0xffffff && color0 == 0x000000)
                color1 = gx_no_color_index;
        }
    }
    /* Three cases really matter */
    if (color0 == gx_no_color_index) {
        /* One color */
        cdev->curflags |= color_flags(color1);
        if ((code = djvu_check_current(cdev, color1)) >= 0)
            code = runmapbld_put_bitmap(cdev->curmask, base, sourcex, sraster, 
					0x00, x, y, w, h);
    } else if (color1 == gx_no_color_index) {
        /* One color, reverse video */
        cdev->curflags |= color_flags(color0);
        if ((code = djvu_check_current(cdev, color0)) >= 0)
            code = runmapbld_put_bitmap(cdev->curmask, base, sourcex, sraster, 
					0xff, x, y, w, h);
    } else {
        /* Two colors */
        cdev->curflags |= color_flags(color0);
        cdev->curflags |= color_flags(color1);
        if ((code = djvu_check_current(cdev, gx_no_color_index)) >= 0)
            code = runmapbld_put_rect(cdev->curmask, x, y, w, h);
    }
    if (code < 0) 
        return code;
    /* Save chrome info */
    if (cdev->curchrome)
        if ((code = chrome_put_bitmap(cdev->gchrome, base, sourcex, sraster, 
                                      x, y, w, h, color0, color1)) < 0)
            return code;
    return 0;
}

/* GS callback: copy color pixmap */
private int
djvu_copy_color(gx_device *dev,
                   const byte * base, int sourcex, int sraster, gx_bitmap_id id,
                   int x, int y, int w, int h)
{
    gx_device_djvu * const cdev = (gx_device_djvu *)dev;
    byte hascolor = 0;
    int code; 
    /* Check for break */
    fit_copy(dev, base, sourcex, sraster, id, x, y, w, h);
    if (cdev->curbreak) {
        code = djvu_flush_maybe(cdev, x, y, w, h);
        if (code < 0) return code;
    }
    /* Accumulate mask */
    code = djvu_check_current(cdev, gx_no_color_index);
    if (code < 0) return code;
    code = runmapbld_put_rect(cdev->curmask, x, y, w, h);
    if (code < 0) return code;
    /* Save chrome info */
    if (cdev->curchrome)
        if ((code = chrome_put_pixmap(cdev->gchrome, base, sourcex, sraster,
                                      x, y, w, h )) < 0)
            return code;
    /* Color check */
    base = base + 3*sourcex;
    while (!hascolor && h-- > 0) {
        int x = 0;
        const byte *row = base;
        while (x++ < w) {
            byte r = *row++;
            byte g = *row++;
            byte b = *row++;
            hascolor |= ((r^g)|(g^b));
        }
        base += sraster;
    }
    cdev->curflags |= (DLIST_HASGRAY|DLIST_INPURE);
    if (hascolor) cdev->curflags |= DLIST_HASCOLOR;
    return 0;
}

/* ------ path procs ------ */

/* GS callback: postscript operator ``fill'' */
private int
djvu_fill_path(gx_device *dev, const gs_imager_state * pis,
	       gx_path * ppath, const gx_fill_params * params,
	       const gx_device_color *pdcolor, const gx_clip_path * pcpath)
{
    int code;
    gx_device_djvu * const cdev = (gx_device_djvu *)dev;
    gx_color_index color = gx_no_color_index;
    /* Sometimes high level subroutines call each other */
    if (cdev->curflags & DLIST_RECURSIVE)
        return gx_default_fill_path(dev, pis, ppath, params, pdcolor, pcpath);
    /* Segment driver stream */
    code = djvu_flush_current(cdev);
    if (code < 0) return code;
    if (  gx_dc_writes_pure(pdcolor, pis->log_op) 
	  && pis->alpha==gx_max_color_value)
        color = gx_dc_pure_color(pdcolor);
    code = djvu_check_current(cdev, color);
    if (code < 0) return code;
    /* Call default routine */
    cdev->curflags |= DLIST_PATH | DLIST_PATH_FILL | DLIST_RECURSIVE;
    code = gx_default_fill_path(dev, pis, ppath, params, pdcolor, pcpath);
    cdev->curflags &= ~DLIST_RECURSIVE;
    if (code < 0) return code;
    return djvu_flush_current(cdev);
}

/* GS callback:  postscript operator ``stroke'' */
private int
djvu_stroke_path(gx_device *dev, const gs_imager_state * pis,
		 gx_path * ppath, const gx_stroke_params * params,
		 const gx_drawing_color *pdcolor, const gx_clip_path * pcpath)
{
    int code;
    gx_device_djvu * const cdev = (gx_device_djvu *)dev;
    gx_color_index color = gx_no_color_index;
    /* Sometimes high level subroutines call each other */
    if (cdev->curflags & DLIST_RECURSIVE)
        return gx_default_stroke_path(dev, pis, ppath, params, pdcolor, pcpath);
    /* Segment driver stream */
    code = djvu_flush_current(cdev);
    if (code < 0) return code;
    if (  gx_dc_writes_pure(pdcolor, pis->log_op) 
	  && pis->alpha==gx_max_color_value)
        color = gx_dc_pure_color(pdcolor);
    code = djvu_check_current(cdev, color);
    if (code < 0) return code;
    /* Call default routine */
    cdev->curflags |= DLIST_PATH | DLIST_RECURSIVE;
    code = gx_default_stroke_path(dev, pis, ppath, params, pdcolor, pcpath);
    cdev->curflags &= ~DLIST_RECURSIVE;
    return djvu_flush_current(cdev);
}

/* ------ image procs ------ */

/* GS callback:  begin processing an image */
private int 
djvu_begin_typed_image(gx_device *dev,
                       const gs_imager_state *pis, const gs_matrix *pmat,
                       const gs_image_common_t *pim, const gs_int_rect *prect,
                       const gx_drawing_color *pdcolor,
                       const gx_clip_path *pcpath,
                       gs_memory_t *memory, gx_image_enum_common_t **pinfo)
{
    gx_device_djvu * const cdev = (gx_device_djvu *)dev;
    /* Segment driver stream (only when the call is non recursive) */
    if (! (cdev->curflags & DLIST_RECURSIVE)) {
        /* We should here call djvu_flush_current() in order to keep images
           separate.  There are many crazy pdf files however that encode
           images using a number of small images at different resolutions.
           In order to avoid breaking these, we just set a flag that will
           cause the low level routines to call djvu_flush_maybe(). */
        cdev->curbreak = true;
    }
    /* Note: we cannot easily set DLIST_RECURSIVE around image drawing 
       callsbecause we should then override the image procedure vector. */
    return gx_default_begin_typed_image(dev, pis, pmat, pim, prect,
                                        pdcolor, pcpath, memory, pinfo);
}

/* ------ text procs ------ */

/* We want to delimit the text operations by executing custom code
   before and after running function gs_text_enum_procs_t::process(). */

#ifdef DO_NOT_DEFINE
/* The ``normal'' solution (cf. gdevbbox.c) consists in having
   djvu_text_begin() create a subclass of gs_text_enum_t that delegates its
   work to another gs_text_enum_t created with the default function.  This is
   illustrated in gdevbbox and gdevpdft.  Although this solution basically
   works, it seems that something in the ghostscript font renderer works
   differently when the text enumerator is not a gs_show_enum_t. */

typedef struct djvu_text_enum_s {
    gs_text_enum_common;
    gs_text_enum_t *target;
    runmapbld *curmask;
    uint curflags;
    gx_color_index curcolor;
    chrome_pos *curchrome;
} djvu_text_enum;

extern_st(st_gs_text_enum);
gs_private_st_suffix_add1(st_djvu_text_enum, djvu_text_enum, 
			  "djvu_text_enum",
                          djvu_text_enum_enum_ptrs, 
			  djvu_text_enum_reloc_ptrs,
			  st_gs_text_enum, target);

private text_enum_proc_resync(djvu_text_resync);
private text_enum_proc_process(djvu_text_process);
private text_enum_proc_is_width_only(djvu_text_is_width_only);
private text_enum_proc_current_width(djvu_text_current_width);
private text_enum_proc_set_cache(djvu_text_set_cache);
private text_enum_proc_retry(djvu_text_retry);
private text_enum_proc_release(djvu_text_release);

private const gs_text_enum_procs_t djvu_text_procs =
{
    djvu_text_resync, djvu_text_process, djvu_text_is_width_only,
    djvu_text_current_width, djvu_text_set_cache, djvu_text_retry,
    djvu_text_release
};

/* GS callback: begin processing text */
private int
djvu_text_begin(gx_device *dev, gs_imager_state * pis,
		const gs_text_params_t * text, gs_font * font,
		gx_path * path, const gx_device_color * pdcolor,
		const gx_clip_path * pcpath,
		gs_memory_t * mem, gs_text_enum_t ** ppenum)
{
    int code;
    djvu_text_enum *pmte;
    gs_text_enum_t *pte;
    /* Allocate text enumerator */
    rc_alloc_struct_1(pmte, djvu_text_enum, 
		      &st_djvu_text_enum, mem,
		      return_VMerror, 
		      "djvu_text_begin");
    pmte->rc.free = rc_free_text_enum;
    pte = (gs_text_enum_t *)pmte;
    /* Initialize text enumerator */
    code = gs_text_enum_init(pte, &djvu_text_procs,
			     dev, pis, text, font, path, 
			     pdcolor, pcpath, mem);
    if (code < 0) {
	gs_free_object(mem, pmte, "djvu_text_begin");
	return code;
    }
    /* Initialize djvu_text enumerator */
    pmte->target = 0;
    pmte->curmask = 0;
    pmte->curchrome = 0;
    pmte->curflags = DLIST_TEXT;
    pmte->curcolor = gx_no_color_index;
    if (  pmte->pdcolor
          && gx_dc_writes_pure(pmte->pdcolor, pmte->pis->log_op)
	  && pmte->pis->alpha==gx_max_color_value )
        pmte->curcolor = gx_dc_pure_color(pmte->pdcolor);
    /* Create default text enumerator */
    code = gx_default_text_begin(dev, pis, text, font, 
                                 path, pdcolor, pcpath, mem,
                                 &pmte->target );
    if (code < 0) {
	gs_free_object(mem, pmte, "djvu_text_begin");
	return code;
    }
    /* Copy dynamic components and return */
    gs_text_enum_copy_dynamic(pte, pmte->target, false);
    *ppenum = (gs_text_enum_t *) pmte;
    return code;
}

/* GS text callback: reset text iterator */
private int
djvu_text_resync(gs_text_enum_t *pte, const gs_text_enum_t *pfrom)
{
    int code;
    djvu_text_enum *const pmte = (djvu_text_enum *) pte;
    if ((pte->text.operation ^ pfrom->text.operation) & ~TEXT_FROM_ANY)
	return_error(gs_error_rangecheck);
    if (pmte->curmask) 
	runmapbld_close(pmte->curmask, 0);
    /* Forward */
    code = gs_text_resync(pmte->target, pfrom);
    pte->text = pfrom->text;
    gs_text_enum_copy_dynamic(pte, pfrom, false);
    /* Reinitialize djvu_text enum */
    pmte->curmask = 0;
    pmte->curchrome = 0;
    pmte->curflags = DLIST_TEXT;
    pmte->curcolor = gx_no_color_index;
    if (  pmte->pdcolor
          && gx_dc_writes_pure(pmte->pdcolor, pmte->pis->log_op)
	  && pmte->pis->alpha==gx_max_color_value )
        pmte->curcolor = gx_dc_pure_color(pmte->pdcolor);
    return code;
}

/* GS text callback: process text */
private int
djvu_text_process(gs_text_enum_t * pte)
{
    int code;
    djvu_text_enum *const pmte = (djvu_text_enum *) pte;
    gx_device_djvu * const cdev = (gx_device_djvu *)pmte->dev;
    bool dodraw = (pmte->text.operation & TEXT_DO_DRAW);
    /* do noting on recursive calls */
    if (cdev->curflags & DLIST_RECURSIVE)
        dodraw = false;
    /* install text state */
    if (dodraw) {
	/* save current state */
	code = djvu_flush_current(cdev);
	if (code < 0) return code;
	/* install text state */
	cdev->curmask = pmte->curmask;
	cdev->curcolor = pmte->curcolor;
	code = djvu_check_current(cdev, pmte->curcolor);
	cdev->curflags = pmte->curflags;
        cdev->curflags |= DLIST_RECURSIVE;
    }
    /* process */
    code = gs_text_process(pmte->target);
    /* restore */
    if (dodraw) {
        cdev->curflags &= ~DLIST_RECURSIVE;
	if (code > 0) {
	    /* will be called again */
	    pmte->curmask = cdev->curmask;
	    pmte->curflags = cdev->curflags;
	    pmte->curcolor = cdev->curcolor;
            pmte->curchrome = cdev->curchrome;
	    cdev->curmask = 0;
	    cdev->curflags = 0;
	    cdev->curcolor = 0;
            cdev->curchrome = 0;
	} else {
	    /* finished */
	    int fcode;
	    pmte->curcolor = cdev->curcolor;
	    pmte->curflags = cdev->curflags;
	    pmte->curmask  = 0;
            pmte->curchrome = 0;
	    fcode = djvu_flush_current(cdev);
	    if (fcode<0 && code>=0)
		code = fcode;
	}
    }
    /* return to caller */
    gs_text_enum_copy_dynamic(pte, pmte->target, true);
    return code;
}

/* GS text callback */
private bool
djvu_text_is_width_only(const gs_text_enum_t *pte)
{
    const djvu_text_enum *const pmte = (const djvu_text_enum *)pte;
    return gs_text_is_width_only(pmte->target);
}

/* GS text callback */
private int
djvu_text_current_width(const gs_text_enum_t *pte, gs_point *pwidth)
{
    const djvu_text_enum *const pmte = (const djvu_text_enum *)pte;
    return gs_text_current_width(pmte->target, pwidth);
}

/* GS text callback */
private int
djvu_text_set_cache(gs_text_enum_t *pte, const double *values,
                       gs_text_cache_control_t control)
{
    djvu_text_enum *const pmte = (djvu_text_enum *) pte;
    int code = gs_text_set_cache(pmte->target, values, control);
    gs_text_enum_copy_dynamic(pte, pmte->target, true);
    return code;
}

/* GS text callback */
private int
djvu_text_retry(gs_text_enum_t *pte)
{
    djvu_text_enum *const pmte = (djvu_text_enum *) pte;
    return gs_text_retry(pmte->target);
}

/* GS text callback */
private void
djvu_text_release(gs_text_enum_t *pte, client_name_t cname)
{
    djvu_text_enum *const pmte = (djvu_text_enum *)pte;
    gs_text_release(pmte->target, cname);
    gx_default_text_release(pte, cname);
    if (pmte->curmask) runmapbld_close(pmte->curmask, 0);
    pmte->curmask = 0;
}

#else /* !defined(DO_NOT_DEFINE) */

/* The default text wrapper is based on ugly hack.  Function djvu_text_begin()
   creates a default text enumerator and replaces its statically allocated
   procedure vector by a dynamically allocated procedure vector containing the
   usual procedure, plus a pointer to the original procedures, plus whatever
   additional fields are needed by the wrapper.  It works as long as the
   default text enumerator does not extend the procedure vector itself.  The
   fat procedure vector and anything inside must be allocated with an
   allocator without garbage collection.  Otherwise the garbage collector
   would not be able to properly mark these objects and would reclaim the
   memory at once. */

typedef struct fat_text_enum_procs_s {
    gs_text_enum_procs_t procs;
    const gs_text_enum_procs_t *origprocs;
    void (*origfree)(gs_memory_t*, void*, client_name_t);
    p2mem *pmem;
    runmapbld *curmask;
    uint curflags;
    gx_color_index curcolor;
    chrome_pos *curchrome;
} fat_text_enum_procs_t;

/* GS finalization callback */
private void
djvu_text_free(gs_memory_t * memory, void *vpte, client_name_t cname)
{
    gs_text_enum_t *pte = (gs_text_enum_t *)vpte;
    fat_text_enum_procs_t *fat = (fat_text_enum_procs_t *)pte->procs;
    fat->origfree(memory, vpte, cname);
    if (fat->curmask) runmapbld_close(fat->curmask, 0);
    p2mem_free(fat->pmem, fat);
}

/* GS callback: reinitialize text iterator */
#ifdef text_enum_proc_resync
private int
djvu_text_resync(gs_text_enum_t *pte, const gs_text_enum_t *pfrom)
{
    fat_text_enum_procs_t *fat = (fat_text_enum_procs_t *)pte->procs;
    int code;
    if ((pte->text.operation ^ pfrom->text.operation) & ~TEXT_FROM_ANY)
	return_error(gs_error_rangecheck);
    /* delegate */
    code = fat->origprocs->resync(pte, pfrom);
    /* reset additional fat components */
    if (fat->curmask) 
	runmapbld_close(fat->curmask, 0);
    fat->curmask = 0;
    fat->curchrome = 0;
    fat->curflags = DLIST_TEXT;
    fat->curcolor = gx_no_color_index;
    if (  pte->pdcolor
          && gx_dc_writes_pure(pte->pdcolor, pte->pis->log_op)
	  && pte->pis->alpha==gx_max_color_value )
        fat->curcolor = gx_dc_pure_color(pte->pdcolor);
    return code;
}
#endif

/* GS callback: process text */
private int
djvu_text_process(gs_text_enum_t * pte)
{
    fat_text_enum_procs_t *fat = (fat_text_enum_procs_t *)pte->procs;
    gx_device_djvu * const cdev = (gx_device_djvu *)pte->dev;
    bool dodraw = (pte->text.operation & TEXT_DO_DRAW);
    int code;
    /* do noting on recursive calls */
    if (cdev->curflags & DLIST_RECURSIVE)
        dodraw = false;
    /* install text state */
    if (dodraw) {
	/* save current state */
	code = djvu_flush_current(cdev);
	if (code < 0) return code;
	/* install text state */
	cdev->curmask = fat->curmask;
	cdev->curcolor = fat->curcolor;
	code = djvu_check_current(cdev, fat->curcolor);
	if (code < 0) return code;
	cdev->curflags = fat->curflags;
	cdev->curchrome = fat->curchrome;
        cdev->curflags |= DLIST_RECURSIVE;
    }
    /* delegate */
    code = fat->origprocs->process(pte);
    /* restore text state */
    if (dodraw) {
        cdev->curflags &= ~DLIST_RECURSIVE;
	if (code > 0) {
	    /* will be called again */
	    fat->curmask = cdev->curmask;
	    fat->curflags = cdev->curflags;
	    fat->curcolor = cdev->curcolor;
	    fat->curchrome = cdev->curchrome;
	    cdev->curmask = 0;
	    cdev->curflags = 0;
	    cdev->curcolor = 0;
	    cdev->curchrome = 0;
	} else {
	    /* finished */
	    int fcode;
	    fat->curcolor = cdev->curcolor;
	    fat->curflags = cdev->curflags;
	    fat->curmask  = 0;
	    cdev->curchrome = 0;
	    fcode = djvu_flush_current(cdev);
	    if (fcode<0 && code>=0) 
		code = fcode;
	}
    }
    return code;
}

/* GS callback: start processing text */
private int
djvu_text_begin(gx_device *dev, gs_imager_state * pis,
		const gs_text_params_t * text, gs_font * font,
		gx_path * path, const gx_device_color * pdcolor,
		const gx_clip_path * pcpath,
		gs_memory_t * mem, gs_text_enum_t ** ppenum)
{
    gx_device_djvu * const cdev = (gx_device_djvu *)dev;
    fat_text_enum_procs_t *fat;
    gs_text_enum_t *pte;
    int code;
    /* Create fat procedure vector */
    if (! (fat = p2mem_alloc(cdev->pmem, sizeof(fat_text_enum_procs_t))))
	return_VMerror;
    /* Create default text enumerator */
    code = gx_default_text_begin(dev, pis, text, font, path, pdcolor, 
				 pcpath, mem, &pte );
    if (code < 0) {
	p2mem_free(cdev->pmem, fat);
	return code;
    }
    /* Initialize fat procedure vector */
    fat->procs = *pte->procs;
    fat->origprocs = pte->procs;
    fat->origfree = pte->rc.free;
    fat->procs.process = djvu_text_process;
#ifdef text_enum_proc_resync
    fat->procs.resync = djvu_text_resync;
#endif
    fat->pmem = cdev->pmem;
    fat->curmask = 0;
    fat->curchrome = 0;
    fat->curflags = DLIST_TEXT;
    fat->curcolor = gx_no_color_index;
    if (  pte->pdcolor
          && gx_dc_writes_pure(pte->pdcolor, pte->pis->log_op)
	  && pte->pis->alpha==gx_max_color_value )
        fat->curcolor = gx_dc_pure_color(pte->pdcolor);
    /* Mutate returned pte */
    pte->rc.free = djvu_text_free;
    pte->procs = (gs_text_enum_procs_t *)fat;
    *ppenum = pte;
    return code;
}

#endif




/* ======================================
      L O W   C O L O R   I M A G E S
   ====================================== */

/* Drawlist components with multiple colors usually represent images.  Some
   images have a small number of colors (especially if they were encoded using
   an indexed color model).  The following code examines these images and
   sometimes breaks them into pure color components. */

/* Internal: size of per-color runmapbld */
#define lowcolor_bldsz 170

/* Internal: subclassed payload for color hash table */
typedef struct lowcolordata_s {
    colordata cdata;
    runmapbld *bld;
    runmap *map;
} lowcolordata;

/* Internal: release function for lowcolordata */
private void
lowcolordata_release(p2mem *mem, void *payload)
{
    lowcolordata *cd = payload;
    runmapbld_close(cd->bld, 0);
    runmap_free(cd->map);
}

/* Internal: sorting function for lowcolordata pointers */
private int
lowcolordata_sortsub(const void *a, const void *b)
{
    lowcolordata *cda = *(lowcolordata**)a;
    lowcolordata *cdb = *(lowcolordata**)b;
    return cdb->cdata.w - cda->cdata.w;
}

/* Internal: color distance test */
private inline int
lowcolor_distance(lowcolordata *cd1, lowcolordata *cd2)
{
    gx_color_index c1 = cd1->cdata.color;
    gx_color_index c2 = cd2->cdata.color;
    if ((c1 ^ c2) & 0xF0F8E0) { /* quick filter */
        int dr = (byte)(c1>>16) - (byte)(c2>>16);
        int dg = (byte)(c1>>8) - (byte)(c2>>8);
        int db = (byte)(c1) - (byte)(c2);
        /* Following difference range from 0 to 0xf */
        return ( 5*dr*dr + 9*dg*dg + 2*db*db ) >> 16;
    }
    return 0;
}

/* Internal: perimeter cost (threshold adjustment) */
#define lowcolor_perimeter_cost 8

/* Internal: play the chrome data, build a colormap,
   compute various perimeters, build runmap for each 
   color drawlist component.  Returns a positive
   status if the image must remain in the background. */
private int
lowcolor_separate(gx_device_djvu *cdev, drawlist *dl, 
                  htable *colorhash, int maxcolors)
{
    int code;
    p2mem *mem = cdev->pmem;
    lowcolordata **band = 0;
    int size;
    int w, h, xb, yb;
    lowcolordata *cd;
    int raster;
    int nbands;
    int bandh;
    int ncolors;
    uint perim;
    uint hardperim;
    /* Determine band size and allocate buffer */
    w = dl->mask->xmax - dl->mask->xmin + 1;
    h = dl->mask->ymax - dl->mask->ymin + 1;
    raster = w;
    nbands = 1;
    for (;;) {
        bandh = (h + nbands - 1) / nbands;
        size = raster * bandh * sizeof(lowcolordata*);
        if (size <= cdev->maxbitmap)
            if ((band = p2mem_alloc(mem, size)))
                break;
        if (bandh < 16)
            return 1;
        nbands += 1;
    }
    /* Compute perimeters */
    if (dl->mask && !dl->area)
        runmap_info(dl->mask, &dl->area, &dl->perimeter);
    perim = dl->perimeter * lowcolor_perimeter_cost;
    hardperim = dl->perimeter * 0xf;
    xb = dl->mask->xmin;
    for (yb = dl->mask->ymin; yb <= dl->mask->ymax; yb += bandh) {
        int y;
        int hb = min(bandh, dl->mask->ymax - yb + 1);
        lowcolordata **row;
        /* render band using indexed model */
        memset(band, 0, size);
        code = chrome_play_indexed(dl->chromepos, colorhash, maxcolors,
                                   (colordata**)band, raster, 
                                   xb, yb, w, hb);
        if (code != 0) goto exit;
        /* compute perimeter data */
        row = band;
        for (y = yb; y < yb+hb; y++, row+=raster) {
            int x;
            lowcolordata **r = row;
            lowcolordata *lcd = 0;
            for (x=0; x<w; x++,r++) {
                lowcolordata *cd = r[0];
                if (cd!=lcd && cd && lcd) {
                    perim += lowcolor_perimeter_cost;
                    hardperim += lowcolor_distance(cd,lcd);
                }
                if (y > yb) {
                    lcd = r[-raster];
                    if (cd!=lcd && cd && lcd) {
                        perim += lowcolor_perimeter_cost;
                        hardperim += lowcolor_distance(cd,lcd);
                    }
                }
                lcd = cd;
            }
        }
    }
    /* Perform test on perimeter ratio */
    code = 1;
    ncolors = colorhash->nelems;
#ifdef DEBUG
    if (gs_debug_c(DEBUG_CHAR_LOCOLOR))
        fprintf(stderr,"LC: perim=%d hardperim=%d ncolors=%d\n", 
                perim, hardperim, ncolors);
#endif
    while (perim >= 0x1000000) { perim >>= 1; hardperim >>= 1; }
    if ( hardperim * 100 <= perim * (100 - cdev->threshold) )
        goto exit;
    /* Separate color runmaps */
    for (yb = dl->mask->ymin; yb <= dl->mask->ymax; yb += bandh) {
        int y;
        int hb = min(bandh, dl->mask->ymax - yb + 1);
        lowcolordata **row;
        /* render band (already there if there is only one band) */
        if (nbands > 1) {
            memset(band, 0, size);
            code = chrome_play_indexed(dl->chromepos, colorhash, maxcolors,
                                       (colordata**)band, raster, 
                                       xb, yb, w, hb);
            if (code != 0) goto exit;
        }
        /* extract runs */
        row = band;
        for (y = yb; y < yb+hb; y++, row+=raster) {
            int x = 0;
            lowcolordata **r = row;
            while (x < w) {
                int rx = x;
                lowcolordata *lcd = r[0];
                do { x++; r++; } while (x < w && r[0] == lcd);
                if (lcd) {
                    if (!lcd->bld) {
                        code = runmapbld_open(mem, lowcolor_bldsz, &lcd->bld);
                        if (code < 0) goto exit;
                    }
                    code = runmapbld_write(lcd->bld, y, xb+rx, xb+x-1);
                    if (code < 0) goto exit;
                }
            }
        }
    }
    /* Close runmap builders */
    htable_begin_loop(cd, colorhash) {
        code = runmapbld_close(cd->bld, &cd->map);
        if (code < 0) goto exit;
        runmap_info(cd->map, &cd->cdata.w, 0); 
        cd->bld = 0;
    } htable_end_loop(cd, colorhash);
    /* Success */
    code = 0;
 exit:
    p2mem_free(mem, band);
    return code;
}

/* Internal: process one lowcolor image */
private int
lowcolor_process_one(gx_device_djvu *cdev, drawlist *dl)
{
    int code;
    p2mem *mem = cdev->pmem;
    htable *colorhash = 0;
    int cdmapsize;
    lowcolordata **cdmap = 0;
    lowcolordata *cd;
    drawlist *nextdl;
    int ncolors;
    int i;
    /* Check */
    ASSERT(dl->mask);
    ASSERT(dl->chromepos);
#ifdef DEBUG
    /* Number of colors is small enough */
    if (gs_debug_c(DEBUG_CHAR_LOCOLOR)) {
        fprintf(stderr, "LC: examining");
        drawlist_print(dl);
    }
#endif
    /* Create color histogram */
    colorhash = htable_alloc(mem, sizeof(lowcolordata));
    if (!colorhash) goto exitmem;
    colorhash->payload_release = lowcolordata_release;
    /* Separate colors */
    code = lowcolor_separate(cdev, dl, colorhash, cdev->fgimgcolors); 
    if (code != 0) goto exit;
    ncolors = colorhash->nelems;
    if (ncolors < 1) goto exit;
    /* Select colors to be moved into foreground layer */
    cdmapsize = 0;
    if (! (cdmap = p2mem_alloc(mem, ncolors*sizeof(lowcolordata*))))
        goto exitmem;
    htable_begin_loop(cd, colorhash) {
        if (cd->map) cdmap[cdmapsize++] = cd;
    } htable_end_loop(cd, colorhash);
    if (cdmapsize < 1) goto exit;
    /* Sort separated color masks by area */
    qsort(cdmap, cdmapsize, sizeof(lowcolordata*), lowcolordata_sortsub);
    /* Transform the original component with the heaviest color */
    dl->flags = dl->flags & ~DLIST_INPURE;
    dl->color = cdmap[0]->cdata.color;
    dl->chromepos = 0;
#ifdef DEBUG
    if (gs_debug_c(DEBUG_CHAR_LOCOLOR)) {
        fprintf(stderr,"LC: becomes");
        drawlist_print(dl);
    }
#endif      
    /* Insert all remaining components */
    nextdl = dl->next;
    for (i=1; i<cdmapsize; i++) {
        drawlist *newdl = drawlist_insert(mem, &cdev->head, nextdl);
        if (!newdl) goto exitmem;
        newdl->flags = (dl->flags | DLIST_FOREGROUND) & ~DLIST_INPURE;
        newdl->color = cdmap[i]->cdata.color;
        newdl->mask = cdmap[i]->map;
        cdmap[i]->map = 0;
#ifdef DEBUG
        if (gs_debug_c(DEBUG_CHAR_LOCOLOR)) {
            fprintf(stderr,"LC: plus");
            drawlist_print(newdl);
        }
#endif
    }
    /* Success */
    code = 0;
    goto exit;
 exitmem:
    /* Memory error */
    code = gs_note_error(gs_error_VMerror);
 exit:
    /* Cleanup and return */
    p2mem_free(mem, cdmap);
    htable_free(colorhash);
    return code;
}

/* Main processing function for lowcolor images */
private int
lowcolor_process(gx_device_djvu *cdev)
{
    if (cdev->fgimgcolors > 0) {
        drawlist *dl;
        drawlist *dlnext = cdev->head.first;
        while ((dl = dlnext)) {
            int code;
            dlnext = dl->next;
            if (dl->chromepos && dl->mask) 
                if ((code = lowcolor_process_one(cdev, dl)) < 0)
                    return code;
        }
    }
    return 0;
}





/* ======================================
               D R A W L I S T
         C L A S S I F I C A T I O N
   ====================================== */

/* Each drawlist record must be classified as either a foreground or a
   background object.  This can become a highly non trivial task when a lot of
   objects overlap.  Imagine for instance a road on a map.  The road might be
   drawn by first drawing a fat black segment, and then drawing a thinner red
   segment over the center of the black segment.  The resulting image shows a
   red road surrounded by two black edges.  The edges result from the
   occlusion of the fat black segment by the thinner red segment.  They
   logically belong to the black segment and are drawn before the red segment.
   But they should be encoded as foreground objects...

   The classification algorithm is based on the minimum description length
   principle.  Each decision affects the number of bits necessary to encode
   the image.  Each decision also affects the quality of the resulting image,
   represented by the number of bits necessary to encode the difference
   between the encoded image and the original image.

   We first assume that all objects are classified as background.  We then
   proceed from the topmost object towards the bottommost object and estimate
   whether classifying the object as foreground would reduce the bit costs of
   the overall image.  Although greedy optimization is not perfect, we can
   obtain satisfactory results (more on this later).

   - An object classified as foreground will be encoded very accurately.  The
     number of bits required by this encoding is roughly proportional to the
     perimeter of the object after removing its occluded parts.  The number of
     bits to describe the residual differences is zero.

   - An object classified as background will be encoded using a lossy scheme
     and less resolution.  Both the encoding and the difference bit costs are
     roughly proportional to the length of the perimeter, *except* for those
     parts of the perimeter that result from occlusions by foreground objects
     located above the current object.  Furthermore, the proportionality
     coefficient depends on the color differences along the object boundary.

   We are then left with several practical problems:

   - Computing the perimeter of a runmap.  This is achieved very efficiently
     by function runmap_info().  The basic idea consists first in adding the
     perimeters of each run considered in isolation, and secondly to remove
     twice the length of the contact lines between runs located on adjacent
     rows.

   - Computing the length of the part of the perimeter which does not result
     from an occlusion by objects located above.  First we compute the
     occlusion as the intersection of the initial mask with a runmap
     representing all objects located above.  Then we compute the final mask
     by removing the occlusion using runmap_andnot().  The following equality
     allows us to efficiently compute the relevant perimeter lengths:
          perimeter(initial) + perimeter(occlusion) = 
              perimeter(final) + 2 * masked_part_of_inital_perimeter

   - Evaluating the color differences along the object boundaries that are not
     arising from an occlusion.  An exact computation would be highly
     time-consuming.  Therefore we make the following simplifications: (a) we
     compute the largest color difference only (instead of averaging the color
     differences along the boundary), and (b) we only compute the color
     differences with respect to a small number of background candidates
     preselected during a preliminary pass on the drawlist.

     This approximation works because it undoes some nasty side effects of the
     greedy optimization procedure.  At each time indeed, we assume that the
     objects located below the current object are all going to be background
     objects.  When we compute the bit costs for encoding an object as
     background, we should also consider that it touches objects located
     below, which eventually might be classified as foreground objects (c.f.
     the red road with black edges).  We should not consider these boundaries
     when evaluating the cost of encoding the current object as background,
     but we cannot do it in a single pass because we do not know yet how these
     objects will turn out.  The above approximation somehow works like an
     oracle that guesses which objects will turn out being background objects. */


/* Must be called before classify_drawlist. 
   Spot good background candidates and link them via pointer bglink.
   This function searches large path fills that define a local background
   color. Every drawlist element can access potential background elements
   located below using the bglink linked list. */
private int
identify_bg_candidates(gx_device_djvu *cdev)
{
    /* Educated guesses */
    int min_fill = 3;
    int min_area = cdev->HWResolution[0] * cdev->HWResolution[1] / 4;
    drawlist *dl = cdev->head.last;
    /* Search candidate background fills */
    drawlist *kdl = dl;
    while (dl) {
        /* Search */
        while (dl) {
            if (dl->mask && !dl->area)
                runmap_info(dl->mask, &dl->area, &dl->perimeter);
            if (dl->mask && (dl->flags & DLIST_PATH_FILL)) {
                uint bboxw = dl->mask->xmax - dl->mask->xmin + 1;
                uint bboxh = dl->mask->ymax - dl->mask->ymin + 1;
                if (dl->area > min_area)
                    if (dl->area * min_fill >= bboxw * bboxh)
                        break; /* Got a bg candidate */
            }
            dl = dl->prev;
        }
#ifdef DEBUG
        if (gs_debug_c(DEBUG_CHAR_DLIST)) {
            fprintf(stderr,"bgcan ");
            drawlist_print(dl);
        }
#endif
        /* Link */
        while (kdl != dl) {
            kdl->bglink = dl;
            kdl = kdl->prev;
        }
        /* Proceed */
        dl = (dl ? dl->prev : dl);
    }
    return 0;
}

/* Internal: Color distance */
private inline int
color_distance(gx_color_index c1, gx_color_index c2)
{
    int dr = (byte)(c1>>16) - (byte)(c2>>16);
    int dg = (byte)(c1>>8) - (byte)(c2>>8);
    int db = (byte)(c1) - (byte)(c2);
    /* Following difference range from 0 to 0xfffff */
    int d = 5*dr*dr + 9*dg*dg + 2*db*db; 
    /* Compute final distance. Very small distances are hardly
       visible and actually must be considered as small.  Beyond that,
       the mere fact that items were drawn using different operators
       indicates that their border probably is perceptually more
       meaningful than their color indicate.  The magic formula below
       attempts to quantify these facts. */
    return min(255, (d >> 8));
}

/* Internal: Return the maximal color distance between the specified object
   and the potential background candidates. */
private int
scan_bg_candidates(p2mem *mem, drawlist *dl, int *pdist)
{
    drawlist *kl = dl->bglink;
    runmap *mask = dl->mask;
    int code = 0;
    int dist = 0;
    int del = 0;
    /* Scan bg candidates */
    while (kl && mask) {
        /* This code sucks because it considers all candidate background
           objects that are overlapped by the visible part of the current
           object.  It should only consider those candidates intersecting the
           part of the boundary that does not result from an occlusion by a
           foreground object.  Possible but tough.  */
        if (runmap_hittest(mask, kl->mask)) {
            int ndist = 160;
            if (kl->color != gx_no_color_index) 
                ndist = color_distance(dl->color, kl->color);
            dist = max(dist, ndist);
            code = runmap_andnot(mem, mask, kl->mask, del, &mask);
            if (code < 0) return code;
            del = 1;
        }
        kl = kl->bglink;
    }
    /* Compare with default white background */
    if (mask) {
        int ndist = color_distance(dl->color, 0xffffff);
        dist = max(dist, ndist);
        if (del) runmap_free(mask);
    }
    /* Return final distance.  */
    *pdist = dist;
    return 0;
}

/* Scan the drawing list and set flag DLIST_FOREGROUND or DLIST_BACKGROUND in
   each element.  The mask of each foreground element is clipped in order to
   only keep the visible part of the element in either the background or
   foreground layer.  Returns a runmap representing the pixels classified as
   foreground. Also returns the accrued flags describing the colors of the
   foreground and background pixels. */
private int
classify_drawlist(p2mem *mem, gx_device_djvu *cdev,
                  runmap **fgmapout, uint *fgflagsout, uint *bgflagsout )
{
    int code = 0;
    runmap *fgmap = 0;
    runmap *fgmapi = 0;
    uint fgflags = 0;
    runmap *bgmap = 0;
    runmap *bgmapi = 0;
    uint bgflags = 0;
    drawlist *dl = cdev->head.last;
    int nthreshold = 100 - cdev->threshold;
#ifdef DEBUG
    bool debug = gs_debug_c(DEBUG_CHAR_DLIST);
#endif
    /* Iterate */
    while (dl) {
        drawlist *dlprev = dl->prev;
        runmap *occlusion = 0;
        runmap *clipped = 0;
	runmap *tmp = 0;
        int dist = -1;
        int initial_perim;
        int occlusion_perim;
        int clipped_perim;
        int bg_perim;
	/* Objects with inpure color or already marked as background */
	if (dl->flags & (DLIST_INPURE|DLIST_BACKGROUND)) {
            dl->flags &= ~DLIST_FOREGROUND;
	    dl->flags |= DLIST_BACKGROUND;
	    goto cleanup;
	}
        /* Determine occlusions by background objects */
        if ( (code = runmap_and(mem, dl->mask, bgmapi, 0, &occlusion)) < 0 ||
             (code = runmap_and(mem, dl->mask, bgmap, 0, &tmp)) < 0        ||
             (code = runmap_or(mem, tmp, occlusion, 3, &occlusion)) < 0     )
            return code;
        /* Applies background occlusion */
        if (occlusion) {
            code = runmap_andnot(mem, dl->mask, occlusion, 3, &dl->mask);
            if (code < 0) return code;
            /* Although we should logically recompute the perimeter here,
               experience indicates that it helps to simply keep the old
               perimeter because occlusion by background objects often hint
               that this object should go into the background as well. */
        }
        /* Determine occlusions by foreground objects */
        if ( (code = runmap_and(mem, dl->mask, fgmapi, 0, &occlusion)) < 0 ||
             (code = runmap_and(mem, dl->mask, fgmap, 0, &tmp)) < 0        ||
             (code = runmap_or(mem, tmp, occlusion, 3, &occlusion)) < 0     )
            return code;
        /* Applies foreground occlusion */
        if (occlusion) {
            /* Compute clipped mask */
            initial_perim = dl->perimeter;
            runmap_info(occlusion, 0, &occlusion_perim);
            code = runmap_andnot(mem, dl->mask, occlusion, 2, &clipped);
            if (code < 0) return code;
            /* Compute perimeter after occlusion */
            runmap_info(clipped, &dl->area, &dl->perimeter);
            clipped_perim = dl->perimeter;
            /* Compute length of background boundary */
            bg_perim = (initial_perim - occlusion_perim + clipped_perim ) / 2;
        } else {
            /* Compute perimeters without occlusions */
            occlusion_perim = 0;
            initial_perim = clipped_perim = bg_perim = dl->perimeter;
        }
        /* Object marked as text or already marked as foreground */
        if (dl->flags & (DLIST_TEXT|DLIST_FOREGROUND)) {
            dl->flags |= DLIST_FOREGROUND;
            goto cleanup;               
        }
        /* It is true that internal boundaries caused by occlusions do not
           contribute to the cost of coding the object in the background
           (e.g. text on a solid background).  The same cannot be said from
           external boundaries caused by occlusions.  Consider for instance an
           object delineated by a thin foreground border: all its boundaries
           are caused by the border occlusion, and yet it is untrue that such
           an object can be coded in the background at zero cost.  This cost
           critically depends on the border width, but this is too difficult
           to measure.  The following adjustement attempts to count such
           external boundaries for a fraction of the cost of a regular
           background boundary.  This is not perfect.  Yet counting a non zero
           value gives the user a chance to correct possible problems by
           adjusting the gobal threshold. */
        bg_perim += min(initial_perim, clipped_perim) / 2;
        /* Determine color distance with related bg candidates */
        code = scan_bg_candidates(mem, dl, &dist);
        if (code < 0) return code;
#ifdef DEBUG
        if (debug)
            fprintf(stderr,"---- %3d * %6d ? %6d\n", 
                    dist, bg_perim, clipped_perim);
#endif        
        /* Renormalize in order to avoid integer overflows */
        while (bg_perim >= 0x10000 || clipped_perim >= 0x10000) {
            bg_perim >>= 1;
            clipped_perim >>= 1;
        }
        /* Choose option with minimum estimated description length */
        if (bg_perim * dist * 100 < clipped_perim * nthreshold * 256) {
            dl->flags |= DLIST_BACKGROUND;
        } else { 
            dl->flags |= DLIST_FOREGROUND;
        }
        /* --- Foreground/background decision has now been made --- */
    cleanup:
#ifdef DEBUG
	if (debug) drawlist_print(dl);
#endif
	/* Add element to the proper mask/flags */
	if (dl->flags & DLIST_FOREGROUND) {
            /* Replace foreground masks by clipped masks */
            if (occlusion) {
                runmap_free(dl->mask);
                dl->mask = clipped;
            }
            /* Check for invisible objects */
            if (! dl->mask)
                dl->flags = 0;
            /* Update global foreground flags and mask */
	    fgflags |= dl->flags;
	    code = runmap_or(mem, fgmapi, dl->mask, 1, &fgmapi);
            if (code >= 0 && runmap_becoming_big(fgmapi)) {
                code = runmap_or(mem, fgmap, fgmapi, 3, &fgmap);
                fgmapi = 0;
            }
	} else {
            /* Get rid of clipped mask (area and perimeter still refer to it) */
            runmap_free(clipped);
            /* Check for invisible objects */
            if (! dl->mask || dl->color == 0xffffff) 
                dl->flags = 0; 
            /* Update global background flags and mask */
	    bgflags |= dl->flags;
	    code = runmap_or(mem, bgmapi, dl->mask, 1, &bgmapi);
            if (code >= 0 && runmap_becoming_big(bgmapi)) {
                code = runmap_or(mem, bgmap, bgmapi, 3, &bgmap);
                bgmapi = 0;
            }
        }
        if (code < 0) return code;
	/* Remove invisible elements */
	if (! dl->flags)
            drawlist_remove(mem, &cdev->head, dl);
        /* Continue */
        dl = dlprev;
    }
    /* Gather global bitmaps */
    code = runmap_or(mem, fgmap, fgmapi, 3, &fgmap);
    if (code < 0) return code;
    runmap_free(bgmapi);
    runmap_free(bgmap);
    /* Remove white foreground objects over empty background.
       These are invisible and yet might prevent bitonal encoding. */
    if (! bgflags) {
        drawlist *dlprev = cdev->head.last;
        while ((dl = dlprev)) {
            dlprev = dl->prev;
	    if ((dl->color == 0xffffff) && (dl->flags & DLIST_FOREGROUND)) {
		code = runmap_andnot(mem, fgmap, dl->mask, 1, &fgmap);
                drawlist_remove(mem, &cdev->head, dl);
		if (code < 0) return code;
	    } 
        }
    }
    /* Return */
    *fgmapout = fgmap;
    *fgflagsout = fgflags;
    *bgflagsout = bgflags;
    return 0; 
}

/* Prepare string describing fg and bg content */
private char *
describe_fg_bg(uint fgflags, uint bgflags)
{
    static char out[40];
    /* Foreground */
    if (!fgflags)
        strcpy(out," fg-empty");
    else if (fgflags & DLIST_HASCOLOR)
        strcpy(out," fg-color");
    else if (fgflags & DLIST_HASGRAY)
        strcpy(out," fg-gray");	    
    else
        strcpy(out," fg-bw");	    	    
    /* Background */
    if (!bgflags)
        strcat(out," bg-empty");
    else if (bgflags & DLIST_HASCOLOR)
        strcat(out," bg-color");
    else
        strcat(out," bg-gray");	  
    /* Background composed of flat colors only */
    if (bgflags && !(bgflags & DLIST_INPURE))
        strcat(out," bg-lineart");
    /* Return in static buffer */
    return out;
}

/* Calls everything in the correct order */
private int
process_drawlist(gx_device_djvu *cdev,
                 runmap **fgmapout, uint *fgflagsout, uint *bgflagsout, 
                 const char **commentout )
{
    int code;
    runmap *fgmap = 0;
    uint fgflags;
    uint bgflags;
#ifdef DEBUG
    if (gs_debug_c(DEBUG_CHAR_P2MEM)) 
        p2mem_diag(cdev->pmem);
#endif
    /* Break potential lowcolor images */
    code = lowcolor_process(cdev);
    if (code < 0) goto exit;
    /* Indentify potential background candidates */
    code = identify_bg_candidates(cdev);
    if (code < 0) goto exit;
    /* Classify drawlist components */
    code = classify_drawlist(cdev->pmem, cdev, &fgmap, &fgflags, &bgflags);
    if (code < 0) goto exit;
#ifdef DEBUG
    if (gs_debug_c(DEBUG_CHAR_P2MEM)) 
        p2mem_diag(cdev->pmem);
#endif
    /* Terminate */
    if (fgflagsout)
        *fgflagsout = fgflags;
    if (bgflagsout)
        *bgflagsout = bgflags;
    if (commentout)
        *commentout = describe_fg_bg(fgflags, bgflags);
    if (fgmapout) {
        *fgmapout = fgmap;
        fgmap = 0;
    }
 exit:
    runmap_free(fgmap);
    return code;
}





/* ======================================
       D J V U M A S K    D E V I C E
   --------------------------------------
    Output foreback mask as a PBM image.
   ====================================== */

/* Device template. */
private djvu_proc_process(djvumask_process);
gx_device_djvu gs_djvumask_device = {
    djvu_device_body("djvumask", djvumask_process)
};

/* Device processing function. */
private int
djvumask_process(gx_device_djvu *cdev)
{
    int code;
    runmap *fgmap;
    uint fgflags;
    uint bgflags;
    const char *comment;
    /* Classify drawlist components */
    code = process_drawlist(cdev, &fgmap, &fgflags, &bgflags, &comment);
    if (code < 0) return code;
    /* Save mask as PBM */
    if (cdev->outputfile) {
        code = runmap_save(fgmap, cdev->outputfile, 
                           0, cdev->width-1, 0, cdev->height-1, comment);
        if (code < 0) return code;
    }
    /* Print message */
    if (! cdev->quiet) {
        fprintf(stdout,"Page %dx%d (%s )\n", 
                cdev->width, cdev->height, comment);
        fflush(stdout);
    }
    /* Terminate */
    runmap_free(fgmap);
#ifdef DEBUG
    if (gs_debug_c(DEBUG_CHAR_P2MEM))
        p2mem_diag(cdev->pmem);
#endif
    return 0;
}



/* ======================================
    F O R E G R O U N D   P A L E T T E
   ====================================== */


/* Compute foreground palette */
private int
quantize_fg_colors(gx_device_djvu *cdev)
{
    /* Variables */
    int code;
    p2mem *mem = cdev->pmem;
    htable *colorhash = 0;
    colordata *cd;
    drawlist *dl;
    /* Compute color histogram */
    if (! (colorhash = colorhash_alloc(mem))) {
        code = gs_note_error(gs_error_VMerror);
        goto exit;
    }
    for (dl=cdev->head.last; dl; dl=dl->prev) 
	if (dl->flags & DLIST_FOREGROUND) 
            if ((code = colorhash_add(colorhash, dl->color, dl->area)) < 0)
                goto exit;
    /* Make a fake palette if foreground is empty */
    if (colorhash->nelems == 0) {
        if (! (cdev->fgpalette = p2mem_alloc(mem, sizeof(gx_color_index)))) {
            code = gs_note_error(gs_error_VMerror);
            goto exit;
        }
        cdev->fgpalette[0] = 0x000000;
        cdev->fgpalettesize = 1;
        code = 0;
        goto exit;
    }
    /* Call color quantizer */
    code = color_quantize(mem, colorhash, cdev->fgcolors,
                          &cdev->fgpalette, &cdev->fgpalettesize);
    if (code < 0)
        goto exit;
#ifdef DEBUG
    if (gs_debug_c(DEBUG_CHAR_COLOR))
	fprintf(stderr,"Found %d colors, reduced to %d colors\n",
		colorhash->nelems, cdev->fgpalettesize);
#endif
    /* Fill palcolor in foreground drawlist elements */
    for (dl=cdev->head.last; dl; dl=dl->prev) {
	if (dl->flags & DLIST_FOREGROUND) {
	    gx_color_index color = dl->color;
	    cd = htable_lookup(colorhash, &color, hash_rgb(color), false);
	    dl->palcolor = cd->w;
	}
    }
    /* Success */
    code = 0;
 exit:
    /* Free everything and return */
    colorhash_free(colorhash);
    return code;
}



/* ======================================
     F O R E G R O U N D   O U T P U T
   ====================================== */

/* Output foreground runs as a CRLE image */
private int
save_foreground(gx_device_djvu *cdev, const char *comment)
{
    int code;
    int fgnum = 0;
    runmap **rmaps = 0;
    gx_color_index *colors = 0;
    drawlist *dl;
    /* Count foreground components */
    for (dl=cdev->head.last; dl; dl=dl->prev)
	if ((dl->flags & DLIST_FOREGROUND) && dl->mask) 
            fgnum += 1;
    /* Allocate rmap and color arrays */
    rmaps = p2mem_alloc(cdev->pmem, sizeof(runmap*) * fgnum);
    colors = p2mem_alloc(cdev->pmem, sizeof(gx_color_index) * fgnum);
    if (fgnum && !(rmaps && colors)) {
        code = gs_note_error(gs_error_VMerror);
        goto exit;
    }        
    /* Fill rmap and color arrays */    
    fgnum = 0;
    for (dl=cdev->head.last; dl; dl=dl->prev)
        if ((dl->flags & DLIST_FOREGROUND) && dl->mask) {
            rmaps[fgnum] = dl->mask;
            colors[fgnum] = dl->palcolor;
            fgnum += 1;
        }
    /* Save */
    code = crle_save(cdev->pmem,
                     cdev->width, cdev->height,
                     cdev->fgpalette, cdev->fgpalettesize,
                     fgnum, rmaps, colors, comment, 
                     cdev->outputfile);
    /* Done */
 exit:
    p2mem_free(cdev->pmem, rmaps);
    p2mem_free(cdev->pmem, colors);
    return code;
}





/* ======================================
     B A C K G R O U N D    O U T P U T
   ====================================== */

/* Save background without subsampling */
private int
save_background_no_subsampling(gx_device_djvu *cdev)
{
    FILE *f = cdev->outputfile;
    int sraster = cdev->width * 3;
    int bandh = cdev->height;
    byte *band = 0;
    int bandsize;
    int nbands = 1;
    int bandy;
    /* Compute bandsize and allocate band buffer */
    for(;;) {
        bandh = (cdev->height + nbands - 1) / nbands;
        bandsize = sraster * bandh;
        if (bandh == 1 || bandsize < cdev->maxbitmap) 
            if ((band = p2mem_alloc(cdev->pmem, bandsize)))
                break;
        if (bandh == 1)
            return_VMerror;
        nbands += 1;
    }
    /* Write PPM header */
    fprintf(f, "P6\n%d %d\n255\n", cdev->width, cdev->height);
    /* Write data */
    for(bandy=0; bandy < cdev->height; bandy += bandh) {
#ifdef DEBUG
        if (gs_debug_c(DEBUG_CHAR_BG))
            fprintf(stderr,"band %d .. %d\n",bandy, bandy+bandh);
#endif
        bandh = min(bandh, cdev->height - bandy);
        memset(band, 0xff, bandsize);
        drawlist_play(&cdev->head, DLIST_BACKGROUND,
                      band, sraster, 0, bandy, cdev->width, bandh);
        if (fwrite(band, sraster, bandh, f) < bandh) {
            p2mem_free(cdev->pmem, band);
            return_error(gs_error_ioerror);
        }
    }
    /* End */
    p2mem_free(cdev->pmem, band);
    return 0;
}

/* Internal: in-place masked subsampling on a single row */
private void 
masksub(byte *rgb, int rgbraster, const byte *mask, int maskraster, 
        int subsample, int subw)
{
    byte *out = rgb;
    static int inv[12*12+1];
    int i,j;
    /* Create inversion table */
    if (! inv[1])
        for (i=1; i<=12*12; i++)
            inv[i] = (0x10000 + (i-1)/2) / i;
    ASSERT(subsample>1 && subsample<=12);
    /* Subsample */
    while (subw > 0) {
        int r, g, b, c;
        byte *rgbrow = rgb;
        const byte *maskrow = mask;
        r = g = b = c = 0;
        for (i=0; i<subsample; i++) {
            for (j=0; j<subsample; j++)
                if (! maskrow[j]) {
                    byte *pix = rgbrow + j + j + j;
                    r += pix[0];
                    g += pix[1];
                    b += pix[2]; 
                    c += 1;
                }
            rgbrow += rgbraster;
            maskrow += maskraster;
        }
        if (c == 0) {
            /* Pixel is entirely masked */
            rgbrow = rgb;
            for (i=0; i<subsample; i++) {
                for (j=0; j<subsample; j++) {
                    byte *pix = rgbrow + j + j + j;
                    r += pix[0];
                    g += pix[1];
                    b += pix[2];
                    c += 1;
                }
                rgbrow += rgbraster;
            }
        }
        /* Store result */
        out[0] = (r * inv[c]) >> 16;
        out[1] = (g * inv[c]) >> 16;
        out[2] = (b * inv[c]) >> 16;
        /* Next pixel */
        out += 3;
        rgb += 3 * subsample;
        mask += subsample;
        subw -= 1;
    }
}

/* Save background with masked subsampling */
private int
save_background(gx_device_djvu *cdev, runmap *mask, int subsample)
{
    FILE *f = cdev->outputfile;
    int subw = (cdev->width + subsample - 1) / subsample;
    int subh = (cdev->height + subsample - 1) / subsample;
    int deadh = subh * subsample - cdev->height;
    int bmapraster = subw * subsample;
    int bmapsize = bmapraster * subsample;
    byte *bmap = 0;
    int bandraster = bmapraster * 3;
    int bandsize;
    int bandh;
    byte *band = 0;
    int nbands = 1;
    int bandy;
    /* Handle full resolution case */
    if (subsample == 1)
        return save_background_no_subsampling(cdev);
    /* Allocate bmap */
    if (! (bmap = p2mem_alloc(cdev->pmem, bmapsize)))
        return_VMerror;
    /* Compute bandsize and allocate band buffer */
    for(;;) {
        bandh = (int)((subh + nbands - 1) / nbands) * subsample;
        bandsize = bandraster * bandh;
        if (bandh <= subsample || bandsize < cdev->maxbitmap) 
            if ((band = p2mem_alloc(cdev->pmem, bandsize)))
                break;
        if (bandh <= subsample) {
            p2mem_free(cdev->pmem, bmap);
            return_VMerror;
        }
        nbands += 1;
    }
    /* Write PPM header */
    fprintf(f, "P6\n%d %d\n255\n", subw, subh);
    /* Iterate on bands */
    for(bandy = -deadh; bandy < cdev->height; bandy += bandh) {
        int ry;
#ifdef DEBUG
        if (gs_debug_c(DEBUG_CHAR_BG))
            fprintf(stderr,"band %d .. %d\n", bandy, bandy+bandh);
#endif
        /* Render band */
        bandh = min(bandh, cdev->height - bandy);
        memset(band, 0xff, bandsize);
        drawlist_play(&cdev->head, DLIST_BACKGROUND,
                      band, bandraster, 0, bandy, cdev->width, bandh);
        /* Iterate on subsampled rows */
        for (ry = bandy; ry < bandy + bandh; ry += subsample) {
            byte *bandrow = band + (ry - bandy) * bandraster;
            byte *bmaprow = bmap; 
            uint y;
            /* Render bmap */
            memset(bmap, 1, bmapsize);
            for (y = max(0,ry); 
                 y < (uint)(ry+subsample); 
                 y++, bmaprow += bmapraster) {
                memset(bmaprow, 0, cdev->width);
                if (mask && y>=mask->ymin && y<=mask->ymax) {
                    byte *data = mask->data + mask->rows[y - mask->ymin];
                    byte *dataend = mask->data + mask->rows[y - mask->ymin + 1];
                    uint x = 0;
                    while (data < dataend) {
                        rl_decode(data, x);
                        if (data < dataend) {
                            uint x1 = x;
                            rl_decode(data, x);
                            if (x > x1 && x <= bmapraster)
                                memset(bmaprow + x1, 1, x - x1);
                        }
                    }
                }
            }
            /* Subsample row */
            masksub(bandrow, bandraster, bmap, bmapraster, subsample, subw);
            /* Save subsampled row */
            if (fwrite(bandrow, 3, subw, f) < subw) {
                p2mem_free(cdev->pmem, band);
                p2mem_free(cdev->pmem, bmap);
                return_error(gs_error_ioerror);
            }
        }
    }
    /* End */
    p2mem_free(cdev->pmem, band);
    p2mem_free(cdev->pmem, bmap);
    return 0;
}




/* ======================================
       D J V U S E P    D E V I C E
   --------------------------------------
   Output separation file:
   - foreground as a CRLE image file
   - background (possibly) as a PPM image file
   - optional comment lines
   ====================================== */

/* Device template. */
private djvu_proc_process(djvusep_process);
gx_device_djvu gs_djvusep_device = {
    djvu_device_body("djvusep", djvusep_process)
};

/* Device processing function. */
private int
djvusep_process(gx_device_djvu *cdev)
{
    int code;
    runmap *fgmap;
    uint fgflags;
    uint bgflags;
    const char *comment;
    /* Classify drawlist components */
    code = process_drawlist(cdev, &fgmap, &fgflags, &bgflags, &comment);
    if (code < 0) return code;
    /* Perform color quantization on foreground */
    code = quantize_fg_colors(cdev);
    if (code < 0) return code;
#ifdef DEBUG
    if (gs_debug_c(DEBUG_CHAR_P2MEM))
        p2mem_diag(cdev->pmem);
#endif
    /* Save separation */
    if (cdev->outputfile) {
        /* Generate RLE encoded foreground */
        code = save_foreground(cdev, comment);
        /* Generate PPM background */
        if (code >= 0 && bgflags) {
            int bgsubsample = cdev->bgsubsample;
            if (cdev->autohires && !bgflags)
                bgsubsample = 1;
            code = save_background(cdev, fgmap, bgsubsample);
        }
        /* Generate comments with mark information */
        if (code >=0 ) {
            pdfmark *mark;
            for (mark=cdev->marks; mark; mark=mark->next) {
                fprintf( cdev->outputfile,"# L %s %s\n", 
                         mark->geometry, mark->uri );
            }
        }
        /* Generate comments with text information */
        if (code >= 0 && cdev->extracttext) {
            drawlist *dl;
            for (dl=cdev->head.first; dl; dl=dl->next)
                if (dl->flags & DLIST_TEXT) {
		    const char *isostring = "not implemented";
                    int w = dl->mask->xmax - dl->mask->xmin + 1;
                    int h = dl->mask->ymax - dl->mask->ymin + 1;
                    fprintf(cdev->outputfile,"# T %dx%d+%d+%d (%s)\n",
                            w, h, dl->mask->xmin, dl->mask->ymin,
			    isostring);
                }
        }
        /* Check for errors */
        if (ferror(cdev->outputfile)) 
            code = gs_error_ioerror;
        if (code < 0) 
            return code; 
    }
    /* Print message */
    if (! cdev->quiet) {
        fprintf(stdout,"Page %dx%d (%s )\n",
                cdev->width, cdev->height, comment);
        fflush(stdout);
    }
    /* Terminate */
    runmap_free(fgmap);
#ifdef DEBUG
    if (gs_debug_c(DEBUG_CHAR_P2MEM))
        p2mem_diag(cdev->pmem);
#endif
    return 0;
}



/* ======================================
         T H E   E N D   (for now)
   ====================================== */
